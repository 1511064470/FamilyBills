//
//  ParentEmptyView.h
//  TomatoClock
//
//  Created by jianghua on 2018/7/17.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParentEmptyView : UIView
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
+ (ParentEmptyView *)emptyView;
@end
