//
//  ParentsButton.h
//  商城
//
//  Created by sks on 16/12/1.
//  Copyright © 2016年 韩江华. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParentsButton : UIButton
@property(nonatomic,retain)UILabel*numberLab;
- (instancetype)initWithFrame:(CGRect)frame WithImage:(NSString*)imageStr WithTile:(NSString*)titleStr;
- (instancetype)initWithAllFunctionFrame:(CGRect)frame WithImage:(NSString*)imageStr WithTile:(NSString*)titleStr;
+(UIButton*)createButtonWithFrame:(CGRect)frame WithTitle:(NSString*)title WithImage:(NSString*)imageName;
@end
