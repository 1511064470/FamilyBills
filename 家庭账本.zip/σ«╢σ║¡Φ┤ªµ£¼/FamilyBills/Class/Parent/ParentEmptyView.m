//
//  ParentEmptyView.m
//  TomatoClock
//
//  Created by jianghua on 2018/7/17.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "ParentEmptyView.h"

@implementation ParentEmptyView

+ (ParentEmptyView *)emptyView
{
    return [[[NSBundle mainBundle]loadNibNamed:@"ParentEmptyView" owner:nil options:nil] objectAtIndex:0];
}
@end
