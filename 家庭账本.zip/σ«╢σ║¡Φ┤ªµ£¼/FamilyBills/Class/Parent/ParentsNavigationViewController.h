//
//  ParentsNavigationViewController.h
//  TomatoClock
//
//  Created by jianghua on 2018/7/5.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParentsNavigationViewController : UINavigationController
@property(nonatomic, retain)UIView *alphaView;
@end
