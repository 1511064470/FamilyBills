//
//  ParentsNavigationViewController.m
//  TomatoClock
//
//  Created by jianghua on 2018/7/5.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "ParentsNavigationViewController.h"
#import "UIImage+Image.h"
@interface ParentsNavigationViewController ()<UINavigationControllerDelegate>
@property (nonatomic ,assign) id target;
@end

@implementation ParentsNavigationViewController
@synthesize alphaView;
-(id)initWithRootViewController:(UIViewController *)rootViewController{
    
    
    self = [super initWithRootViewController:rootViewController];
    if (self)
    {
        CGRect frame = self.navigationBar.frame;
        alphaView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height+20)];
        alphaView.backgroundColor = Main_Color;
        alphaView.alpha=0.0;
        [self.view insertSubview:alphaView belowSubview:self.navigationBar];
        [self.navigationBar setBackgroundImage:[UIImage imageWithColor:[UIColor clearColor]] forBarMetrics:UIBarMetricsDefault];
        self.navigationBar.shadowImage=[UIImage imageWithColor:[UIColor clearColor]];
    }
    return self;
}
+ (void)initialize
{
    UINavigationBar *bar = [UINavigationBar appearanceWhenContainedIn:self, nil];
    //  nc.navigationBar.translucent = NO;
    //去掉导航条的半透明
    //    bar.translucent = NO;
    [bar setTintColor:[UIColor whiteColor]];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    NSString *deviceType = [UIDevice currentDevice].model;
    dict[NSFontAttributeName] = Font(18.0);
    
    dict[NSForegroundColorAttributeName] = [UIColor whiteColor];
    
    [bar setTitleTextAttributes:dict];
    
    //设置系统的返回按钮没有字体
    //    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(0, -100) forBarMetrics:UIBarMetricsDefault];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 获取系统自带滑动手势的target对象
    self.target = self.interactivePopGestureRecognizer.delegate;
    self.delegate = self;
    
}
- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    
    if (viewController == [self.viewControllers firstObject] )
    {
        self.interactivePopGestureRecognizer.delegate = self.target;
    }
}

-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if (self.childViewControllers.count>0)
    {
        // 设置导航条左边按钮的内容，把系统的返回按钮给覆盖，导航控制器的滑动返回功能就消失了
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(backButtonClick) forControlEvents:UIControlEventTouchUpInside];
        button.bounds = CGRectMake(0, 0, 44, 44);
        button.imageEdgeInsets = UIEdgeInsetsMake(0, -25, 0, 0);
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
        self.navigationBarHidden=NO;
        self.interactivePopGestureRecognizer.delegate = nil;
        viewController.automaticallyAdjustsScrollViewInsets=NO;
    }
    [super pushViewController:viewController animated:animated];
}
-(void)backButtonClick
{
    [self popViewControllerAnimated:YES];
}

@end
