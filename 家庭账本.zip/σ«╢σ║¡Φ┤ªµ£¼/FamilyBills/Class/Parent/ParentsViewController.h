//
//  ParentsViewController.h
//  TomatoClock
//
//  Created by jianghua on 2018/7/5.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParentsNavigationViewController.h"

typedef NS_ENUM(NSInteger, FamliyMemberType) {
    FamliyMemberType_Grandfather = 0,
    FamliyMemberType_Grandmother = 1,
    FamliyMemberType_Wife = 2,
    FamliyMemberType_Self = 3,
    FamliyMemberType_Baby = 4,
    FamliyMemberType_Others = 5,
};

@interface ParentsViewController : UIViewController
-(void)isHiddeNavigationTabBar:(BOOL)hidde;
/**
 *  提示框
 *
 *  @param showMessage 提示信息
 */
- (void)showProgress:(NSString *)showMessage;
/**
 *  成功提示框
 *
 *  @param str 成功信息
 */
- (void)showSuccess:(NSString *)str;
/**
 *  提示框消失
 */
- (void)dismissProgress;
/**
 *  错误提示框
 *
 *  @param errorMessage 错误信息
 */
- (void)errorProgress:(NSString *)errorMessage;
/**
 *  失败提示框
 *
 *  @param failedMessage 失败提示
 */
- (void)failedProgress:(NSString *)failedMessage;
/**
 *  创建一个label类型的提示框
 *
 *  @param str 提示信息
 */
- (void)createStrLabelWithStr:(NSString *)str;
/**
 *  展示一个类似alertview的提示框
 *
 *  @param str     提示信息
 *  @param clicked 确定按钮点击事件
 */
- (void)showCustomAlertViewWithString:(NSString *)str ButtonClicked:(void(^)())clicked;//展示一个类似alertview的提示框
@end

