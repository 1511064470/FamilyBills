//
//  ParentsViewController.m
//  TomatoClock
//
//  Created by jianghua on 2018/7/5.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "ParentsViewController.h"
//#import "KVNProgress.h"

@interface ParentsViewController ()<UIGestureRecognizerDelegate>
@property (nonatomic,strong)UIView *alertLabel;
@end

@implementation ParentsViewController
{
    BOOL _show;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets=NO;
    //实现navigationController右滑pop
    self.navigationController.interactivePopGestureRecognizer.delegate = self;
    
}
-(void)isHiddeNavigationTabBar:(BOOL)hidde
{
    ParentsNavigationViewController*nav=(ParentsNavigationViewController*)self.navigationController;
    nav.alphaView.alpha= hidde==YES ? 0.0 :1.0;
    
}
- (void)showProgress:(NSString *)showMessage
{
//    [KVNProgress showWithStatus:showMessage];
}

- (void)showSuccess:(NSString *)str
{
//    [KVNProgress showSuccessWithStatus:str];
}

- (void)dismissProgress
{
//    [KVNProgress dismiss];
}

- (void)errorProgress:(NSString *)errorMessage
{
//    [KVNProgress showErrorWithStatus:errorMessage];
}

- (void)failedProgress:(NSString *)failedMessage
{
//    [KVNProgress showErrorWithStatus:failedMessage];
}

- (void)createStrLabelWithStr:(NSString *)str
{
    if (_show) {
        
        return;
    }else{
        _show = YES;
        CGSize size = [str sizeWithAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:IPhone4_5_6_6P(14, 14, 15, 16)]}];
        self.alertLabel = [[UIView alloc]initWithFrame:CGRectMake(0, 0, size.width + 10, 40)];
        self.alertLabel.backgroundColor = [UIColor colorWithRed:0.0/255.0f green:0.0/255.0f blue:0.0/255.0f alpha:0.7];
        self.alertLabel.center = CGPointMake(Screen_Width / 2, Screen_Height / 2);
        self.alertLabel.layer.cornerRadius = 5;
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0,0,self.alertLabel.bounds.size.width,self.alertLabel.bounds.size.height)];
        label.backgroundColor = [UIColor clearColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.text = str;
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont systemFontOfSize:IPhone4_5_6_6P(14, 14, 15, 16)];
        [self.alertLabel addSubview:label];
        [[[UIApplication sharedApplication].windows objectAtIndex:0] addSubview:self.alertLabel];
        [UIView animateKeyframesWithDuration:0.3 delay:3 options:UIViewKeyframeAnimationOptionLayoutSubviews animations:^{
            self.alertLabel.alpha = 0;
        } completion:^(BOOL finished) {
            [self.alertLabel removeFromSuperview];
            _show = NO;
        }];
    }
    
}

- (void)removeLabel
{
    [self.alertLabel removeFromSuperview];
}

- (void)showCustomAlertViewWithString:(NSString *)str ButtonClicked:(void (^)())clicked
{
    //    [CustomAlertView showWithMsg:str InView:self.app.window ButtonClicked:^{
    //        clicked();
    //    }];
}
@end
