//
//  ParentsButton.m
//  商城
//
//  Created by sks on 16/12/1.
//  Copyright © 2016年 韩江华. All rights reserved.
//

#import "ParentsButton.h"

typedef NS_ENUM(NSInteger, ParentsButtonStyle) {
    
    ParentsButtonStyle_Square        = 0,
    ParentsButtonStyle_AllFunction   = 1,
    
};
@interface ParentsButton()
@property (nonatomic ,assign) ParentsButtonStyle style;
@property (nonatomic ,strong) UILabel *squareLab;
@end
@implementation ParentsButton
{
    NSString*_imageStr;
    NSString*_titleStr;
}

+(UIButton*)createButtonWithFrame:(CGRect)frame WithTitle:(NSString*)title WithImage:(NSString*)imageName
{
    UIButton*buton=[UIButton buttonWithType:UIButtonTypeCustom];
    buton.frame=frame;
    [buton setTitle:title forState:UIControlStateNormal];
    [buton setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    buton.titleLabel.font=[UIFont systemFontOfSize:13];
    [buton setTitleColor:UIColorFromRGB(0xababab) forState:UIControlStateNormal];
    buton.titleEdgeInsets=UIEdgeInsetsMake(0, -15, 0, 15);
    buton.imageEdgeInsets=UIEdgeInsetsMake(0, 40, 0, -40);
    return buton;
}
- (instancetype)initWithFrame:(CGRect)frame WithImage:(NSString*)imageStr WithTile:(NSString*)titleStr 
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _imageStr=imageStr;
        _style = ParentsButtonStyle_Square;
        _titleStr=titleStr;
       [self layoutSquareButton];
        
    }
    return self;
}
- (void)setSelected:(BOOL)selected
{
    [super setSelected:selected];
    if (_style == ParentsButtonStyle_Square) {
        
        self.squareLab.textColor = selected ? Main_Color : [UIColor blackColor];

    }
}
-(void)layoutSquareButton
{
    UIImage*image=[UIImage imageNamed:_imageStr];
    UIImageView*imageView=[[UIImageView alloc]initWithImage:image];
    imageView.frame=CGRectMake((self.width-image.size.width)/2, 0, image.size.width, image.size.height);
    [self addSubview:imageView];
    
    self.squareLab=[[UILabel alloc]init];
    _squareLab.font=[UIFont systemFontOfSize:12];
    _squareLab.frame=CGRectMake(0, image.size.width, self.width, 21);
    _squareLab.text=_titleStr;
    _squareLab.textAlignment=NSTextAlignmentCenter;
    [self addSubview:_squareLab];
    
}
- (instancetype)initWithAllFunctionFrame:(CGRect)frame WithImage:(NSString*)imageStr WithTile:(NSString*)titleStr
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _imageStr=imageStr;
        
        _titleStr=titleStr;
        [self layoutAllFunctionSquareButton];
    }
    return self;
}
-(void)layoutAllFunctionSquareButton
{
    UIImage*image=[UIImage imageNamed:_imageStr];
    UIImageView*imageView=[[UIImageView alloc]initWithImage:image];
    imageView.bounds=CGRectMake(0, 0, image.size.width, image.size.height);
    imageView.center=CGPointMake(self.width/2,14);
    
    [self addSubview:imageView];
    
    UILabel*label=[[UILabel alloc]init];
    label.font=[UIFont systemFontOfSize:14];
    label.center=CGPointMake(self.width/2,39);
    label.bounds=CGRectMake(0, 0, self.width, 12);
    label.text=_titleStr;
    label.textColor=[UIColor whiteColor];
    label.textAlignment=NSTextAlignmentCenter;
    [self addSubview:label];
    
}
@end
