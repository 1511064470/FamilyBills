//
//  DEFINE.h
//  FamilyBills
//
//  Created by jianghua on 2018/7/19.
//  Copyright © 2018年 hjh. All rights reserved.
//

#ifndef DEFINE_h
#define DEFINE_h

#define XMGiPhone6W 375.0
#define XMGiPhone6H 667.0

//程序标题
#define Main_Name @"TomatoClock"
//logo图片宽高比例
#define IMAGESCALE 1.125
//导航条返回按钮图片名称
#define Nav_Back_Btn_Image_Name @"导航返回"
//客服电话
#define CustomerService_TEL @""
//屏幕宽度
#define Screen_Width [UIScreen mainScreen].bounds.size.width
//屏幕高度
#define Screen_Height [UIScreen mainScreen].bounds.size.height

#define kNSUserDefaults [NSUserDefaults standardUserDefaults]

#define kSingleModel [SingleModel shareManager]
// x比例 1.293750 在iPhone7的屏幕上
#define XMGScaleX Screen_Width / XMGiPhone6W
// y比例 1.295775
#define XMGScaleY Screen_Height / XMGiPhone6H
// X坐标
#define LineX(l) l*XMGScaleX
// Y坐标
#define LineY(l) l*XMGScaleY
// H高
#define LineH(l) l*XMGScaleX

// 字体
#define Font(x) [UIFont systemFontOfSize:x*XMGScaleX]

//用户StartTimeStyle
#define k_Total_Family_Money @"k_Total_Family_Money"
#define k_Total_Grandfather_Money @"k_Total_Grandfather_Money"
#define k_Total_Grandmother_Money @"k_Total_Grandmother_Money"
#define k_Total_Wife_Money @"k_Total_Wife_Money"
#define k_Total_Baby_Money @"k_Total_Baby_Money"
#define k_Total_Self_Money @"k_Total_Self_Money"
#define k_Total_Others_Money @"k_Total_Others_Money"

#define k_Date_Grandfather_Money @"k_Date_Grandfather_Money"
#define k_Date_Grandmother_Money @"k_Date_Grandmother_Money"
#define k_Date_Wife_Money @"k_Date_Wife_Money"
#define k_Date_Baby_Money @"k_Date_Baby_Money"
#define k_Date_Self_Money @"k_Date_Self_Money"
#define k_Date_Others_Money @"k_Date_Others_Money"

#define k_Content_Grandfather_Money @"k_Content_Grandfather_Money"
#define k_Content_Grandmother_Money @"k_Content_Grandmother_Money"
#define k_Content_Wife_Money @"k_Content_Wife_Money"
#define k_Content_Baby_Money @"k_Content_Baby_Money"
#define k_Content_Self_Money @"k_Content_Self_Money"
#define k_Content_Others_Money @"k_Content_Others_Money"

#define k_Date_Key @"k_Date_Key"
#define k_Title_Key @"k_Title_Key"
#define k_Money_Key @"k_Money_Key"

#define k_Today_ToalMoney_Key @"k_Today_ToalMoney_Key"
#define k_Today_Date_Key @"k_Today_Date_Key"

#define k_Max_Grandfather_Money @"k_Max_Grandfather_Money"
#define k_Max_Grandmother_Money @"k_Max_Grandmother_Money"
#define k_Max_Wife_Money @"k_Max_Wife_Money"
#define k_Max_Baby_Money @"k_Max_Baby_Money"
#define k_Max_Self_Money @"k_Max_Self_Money"
#define k_Max_Others_Money @"k_Max_Others_Money"

#define k_Min_Money_Date @"k_Min_Money_Date"
#define k_Max_Money_Date @"k_Max_Money_Date"
#define k_Min_Total_Money @"k_Min_Total_Money"
#define k_Max_Total_Money @"k_Max_Total_Money"

//主颜色
#define Main_Color [UIColor colorWithRed:((float)((0xe23304 & 0xFF0000) >> 16))/255.0 green:((float)((0xe23304 & 0xFF00) >> 8))/255.0 blue:((float)(0xe23304 & 0xFF))/255.0 alpha:1.0]
// 弱引用



#define MJWeakSelf __weak typeof(self) weakSelf = self;




#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define kCustomColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]

#define   UIAlertView(aTitle,Amessage)   UIAlertController *alter = [UIAlertController alertControllerWithTitle:aTitle message:Amessage preferredStyle:UIAlertControllerStyleAlert];UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"Cantel" style:UIAlertActionStyleCancel handler:nil];[alter addAction:action1];[self presentViewController:alter animated:YES completion:nil];
#define   UIAlertViewOnlyDelegateConfire(aTitle,Amessage)   UIAlertView*alterView=[[UIAlertView alloc]initWithTitle:aTitle message:Amessage delegate:self cancelButtonTitle:@"Confirm" otherButtonTitles:nil, nil];[alterView show];

#define   UIAlertViewConfire(aTitle,Amessage)   UIAlertView*alterView=[[UIAlertView alloc]initWithTitle:aTitle message:Amessage delegate:nil cancelButtonTitle:@"Confirm" otherButtonTitles:nil, nil];[alterView show];
#define   UIAlertViewDelegateConfire(aTitle,Amessage)   UIAlertView*alterView=[[UIAlertView alloc]initWithTitle:aTitle message:Amessage delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Confirm" , nil];[alterView show];
#define   UIAlertViewDelegateAndTagConfire(aTitle,Amessage,Atag)   UIAlertView*alterView=[[UIAlertView alloc]initWithTitle:aTitle message:Amessage delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"确定" , nil]; alterView.tag=Atag;   [alterView show];
//带属性字符背景色
#define AttributedBackGroundColor [UIColor colorWithRed:234.0/255.0f green:234.0/255.0f blue:234.0/255.0f alpha:1]

//合作身份者id，以2088开头的16位纯数字
#define PartnerID      @""
//收款支付宝账号
#define SellerID       @""
//商户私钥，自助生成
#define kRSAPrivateKey @""


//设备4-6p适配
#define IPhone4_5_6_6P(a,b,c,d) (CGSizeEqualToSize(CGSizeMake(320, 480), [[UIScreen mainScreen] bounds].size) ?(a) :(CGSizeEqualToSize(CGSizeMake(320, 568), [[UIScreen mainScreen] bounds].size) ? (b) : (CGSizeEqualToSize(CGSizeMake(375, 667), [[UIScreen mainScreen] bounds].size) ?(c) : (CGSizeEqualToSize(CGSizeMake(414, 736), [[UIScreen mainScreen] bounds].size) ?(d) : 0))))

#endif /* DEFINE_h */
