//
//  NSDate+Date.m
//  TomatoClock
//
//  Created by jianghua on 2018/7/15.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "NSDate+Date.h"

@implementation NSDate (Date)
+ (NSString *)getNowTimeTimeinterval
{
    NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
    
    NSTimeInterval interval=[dat timeIntervalSince1970];
    
    NSString*timeString = [NSString stringWithFormat:@"%0.f", interval];
    
    return timeString;
}
+ (NSString *)numberOfDaysWithFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate
{
    // 创建一个标准国际时间的日历
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    // 可根据需要自己设置时区.
//    calendar.timeZone = myTimeZone;
    // 获取两个日期的间隔
    NSDateComponents *comp = [calendar components:NSCalendarUnitMinute|NSCalendarUnitSecond|NSCalendarUnitHour fromDate:fromDate toDate:toDate options:NSCalendarWrapComponents];
    NSInteger hour = comp.hour;
    NSInteger minute = comp.minute + hour * 60;
    NSInteger second = comp.second;
    NSString *dateStr = [NSString stringWithFormat:@"%02ld:%02ld",(long)minute,(long)second];
    return dateStr;
}
+ (CGFloat)valueOfDaysWithFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    // 可根据需要自己设置时区.
    //    calendar.timeZone = myTimeZone;
    // 获取两个日期的间隔
    NSDateComponents *comp = [calendar components:NSCalendarUnitMinute|NSCalendarUnitSecond|NSCalendarUnitHour fromDate:fromDate toDate:toDate options:NSCalendarWrapComponents];
    NSInteger hour = comp.hour;
    float second = comp.second;
    NSInteger minute = comp.minute;
    float values = minute + hour * 60 + second / 60.0;
    
    return values;
}
+ (NSString *)getCurrentYear
{
    NSDate *date = [NSDate date];
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
    // 下面的格式设置成你想要转化的样子, 2017-07-24 17:47:10
    [formatter setDateFormat:@"yyyy"];
    [formatter setTimeZone:timeZone];
    NSString * dateStr = [formatter stringFromDate:date];
    return dateStr;
}
+ (NSString *)getCurrentYearAndDate
{
    NSDate *date = [NSDate date];
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
    // 下面的格式设置成你想要转化的样子, 2017-07-24 17:47:10
    [formatter setDateFormat:@"yyyy-MM-dd"];
    [formatter setTimeZone:timeZone];
    NSString * dateStr = [formatter stringFromDate:date];
    return dateStr;
}
+ (NSString *)getCurrentDate
{
    NSDate *date = [NSDate date];
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
    // 下面的格式设置成你想要转化的样子, 2017-07-24 17:47:10
    [formatter setDateFormat:@"MM-dd"];
    [formatter setTimeZone:timeZone];
    NSString * dateStr = [formatter stringFromDate:date];
    return dateStr;
}
+ (NSString *)getDateAndTimeWithDate:(NSDate *)date
{
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
    // 下面的格式设置成你想要转化的样子, 2017-07-24 17:47:10
    [formatter setDateFormat:@"MM-dd HH:mm"];
    [formatter setTimeZone:timeZone];
    NSString * dateStr = [formatter stringFromDate:date];
    return dateStr;
}
+ (NSString *)getCurrentDateAndTime
{
    NSDate *date = [NSDate date];
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
    // 下面的格式设置成你想要转化的样子, 2017-07-24 17:47:10
    [formatter setDateFormat:@"MM-dd HH:mm"];
    [formatter setTimeZone:timeZone];
    NSString * dateStr = [formatter stringFromDate:date];
    return dateStr;
}
+ (NSString *)getCurrentWeek
{
    NSArray *weekdays = @[@"Monday",@"Tuesday",@"Wednesday",@"Thursday",@"Friday",@"Saturday",@"Sunday"];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    NSDateComponents *theComponents = [calendar components:NSCalendarUnitWeekday fromDate:[NSDate date]];
    
    return [weekdays objectAtIndex:theComponents.weekday];
}
//+ (NSDate *)getDateFromTimeInterval:(NSString *)timeinterval
//{
//    
//}

@end
