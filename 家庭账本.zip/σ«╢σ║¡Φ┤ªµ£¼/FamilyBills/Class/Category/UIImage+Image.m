//
//  UIImage+Image.m
//  XianYu
//
//  Created by li  bo on 16/5/28.
//  Copyright © 2016年 li  bo. All rights reserved.
//

#import "UIImage+Image.h"

@implementation UIImage (Image)
+(UIImage*)imageWithCaputureView:(UIView*)view
{
    //开启位图上下文
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, 0);
    //获取上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    //把控件上的图层渲染到上下文,layer只能渲染
    [view.layer renderInContext:context];
    //生成一张图片
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    //关闭上下文
    UIGraphicsEndImageContext();
    
    return image;
}
+(UIImage*)imageWithCilpImage:(UIImage*)image borderWidth:(CGFloat)borderWidth borderColor:(UIColor*)color
{
    //图片的宽度和高度
    CGFloat imageWH = image.size.width;
    
    //圆形的宽度和高度
    CGFloat ovalWH = imageWH + 2*borderWidth;
    
    //开启上下文
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(ovalWH, ovalWH), NO, 0);
    
    //画大圆
    UIBezierPath * path=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, ovalWH, ovalWH)];
    //设置圆环颜色
    [color set];
    //颜色填充
    [path fill];
    //设置裁剪区域
    UIBezierPath *clipPath = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(borderWidth, borderWidth, imageWH, imageWH)];
    //图片剪切
    [clipPath addClip];
    //绘制图片
    [image drawAtPoint:CGPointMake(borderWidth, borderWidth)];
    
    //获取图片
    UIImage *clipImage = UIGraphicsGetImageFromCurrentImageContext();
    //关闭上下文
    UIGraphicsEndImageContext();
    
    return clipImage;
}
+(UIImage*)imageWithWaterImage:(UIImage*)image waterTitle:(NSString*)title waterAttributes:(NSDictionary*)attributes
{
    //0.获取上下文，之前的上下文都是在view的drawRect方法中获取（跟view相关联的上下文layer上下文）
    //此时我们需要绘制图片到新的图片上，因此需要用到位图上下文
    //怎么获取位图上下文，注意位图上下文的获取方式跟layer上下文不一样，位图上下文需要我们手动创建。
    //开启一个位图上下文，注意位图上下文跟view无关联，所以不需要drawRect
    //size:位图上下文的尺寸（新图片的尺寸）
    //opaque:不透明度 YES:不透明 NO:透明  一般都是透明的上下文
    //scale:缩放比例 0:不缩放
    UIGraphicsBeginImageContextWithOptions(image.size,NO, 0);
    
    //1.绘制原生的图片
    [image drawAtPoint:CGPointZero];
    //2.给原生的图片添加文字
    NSString*str = title;
    
    [str drawAtPoint:CGPointMake(image.size.width-80, image.size.height-30) withAttributes:attributes];
    //3.从上下文获取生成的图片
    UIImage*imageWater = UIGraphicsGetImageFromCurrentImageContext();
    
    //4.关闭上下文
    UIGraphicsEndImageContext();
    
    return imageWater;
}
-(UIImage *) imageCompressForWidth:(UIImage *)sourceImage targetValue:(CGFloat)defineValue
{
    
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth;
    CGFloat targetHeight;
    if (width>height)
    {
        targetHeight=defineValue;
        targetWidth=width/(height/targetHeight);
    }
    else
    {
        targetWidth = defineValue;
        targetHeight = height / (width / targetWidth);
    }
    
    CGSize size = CGSizeMake(targetWidth, targetHeight);
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);
    if(CGSizeEqualToSize(imageSize, size) == NO){
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        if(widthFactor > heightFactor){
            scaleFactor = widthFactor;
        }
        else{
            scaleFactor = heightFactor;
        }
        scaledWidth = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        if(widthFactor > heightFactor){
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }else if(widthFactor < heightFactor){
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    UIGraphicsBeginImageContext(size);
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil){
//        NSLog(@"scale image fail");
    }
    
    UIGraphicsEndImageContext();
    return newImage;
}

+ (UIImage *)imageWithColor:(UIColor *)color {

    //描述一个矩形
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    //开启图形上下文
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);

    //获得图形上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();

    //使用color演示填充上下文
    CGContextSetFillColorWithColor(ctx, [color CGColor]);

    //渲染上下文
    CGContextFillRect(ctx, rect);

    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();

    //关闭图形上下文
    UIGraphicsEndImageContext();
    
    return image;
    
}

@end
