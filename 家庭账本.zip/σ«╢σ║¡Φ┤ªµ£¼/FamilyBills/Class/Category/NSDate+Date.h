//
//  NSDate+Date.h
//  TomatoClock
//
//  Created by jianghua on 2018/7/15.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Date)
+ (NSString *)getNowTimeTimeinterval;
+ (NSString *)numberOfDaysWithFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate;
+ (CGFloat)valueOfDaysWithFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate;
+ (NSString *)getCurrentDate;
+ (NSString *)getCurrentYearAndDate;
+ (NSString *)getCurrentYear;
+ (NSString *)getCurrentWeek;
+ (NSString *)getCurrentDateAndTime;
+ (NSString *)getDateAndTimeWithDate:(NSDate *)date;
//+ (NSDate *)getDateFromTimeInterval:(NSString *)timeinterval;
@end
