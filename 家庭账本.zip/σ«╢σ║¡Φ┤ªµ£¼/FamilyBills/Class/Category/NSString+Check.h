//
//  NSDate+Date.h
//  TomatoClock
//
//  Created by jianghua on 2018/7/15.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface NSString (Check)
//数字包括小数点
+ (BOOL) validateMath:(NSString *)string;
//邮箱
+ (BOOL) validateEmail:(NSString *)email;
//手机号码验证
+ (BOOL) validateMobile:(NSString *)mobile;
//+ (NSString *)pureTELString;
+ (BOOL) validateIdCard:(NSString *)value;
//限制只能输入数字
+ (BOOL)validateNumber:(NSString*)number;
//限制只能输入整数
+ (BOOL)validateInteger:(NSString*)number;
//密码
+(BOOL)validatePassWord:(NSString *)pass;
//限制只能输入数字和密码以及特殊字符
+(BOOL) validateString:(NSString *)string;
//中文
+ (BOOL) validateChiness:(NSString *)string;
+ (BOOL) validateUserName:(NSString *)userName;
//数字和X
+ (BOOL)validateIdCardNumber:(NSString *)idCardStr;
//解码url字符串
+ (NSString *)decodeString:(NSString*)encodedString;

@end
