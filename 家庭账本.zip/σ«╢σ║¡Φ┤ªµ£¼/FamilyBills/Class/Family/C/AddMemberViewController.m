//
//  AddMemberViewController.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/19.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "AddMemberViewController.h"

@interface AddMemberViewController ()

@end

@implementation AddMemberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}



@end
