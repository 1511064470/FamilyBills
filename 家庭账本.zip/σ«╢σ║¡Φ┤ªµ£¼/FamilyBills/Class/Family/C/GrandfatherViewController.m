//
//  GrandfatherViewController.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/19.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "GrandfatherViewController.h"

@interface GrandfatherViewController ()<UITextFieldDelegate,UITextViewDelegate>
@property (nonatomic ,strong) UIScrollView *baseScrollView;
@property (nonatomic ,strong) UITextField *amountTF;
@property (nonatomic ,strong) UITextView *matterTV;
@end

@implementation GrandfatherViewController

- (UIScrollView *)baseScrollView
{
    if (!_baseScrollView) {
        _baseScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, Screen_Width, Screen_Height - 64)];
        _baseScrollView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        _baseScrollView.bounces = NO;
        [self.view addSubview:_baseScrollView];
    }
    return _baseScrollView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (self.memberType == FamliyMemberType_Grandfather) {
        self.title = @"爷爷";
    }else if (self.memberType == FamliyMemberType_Grandmother){
        self.title = @"奶奶";
    }else if (self.memberType == FamliyMemberType_Wife){
        self.title = @"妻子";
    }else if (self.memberType == FamliyMemberType_Self){
        self.title = @"丈夫";
    }else if (self.memberType == FamliyMemberType_Baby){
        self.title = @"孩子";
    }else if (self.memberType == FamliyMemberType_Others){
        self.title = @"其他";
    }
    [self layoutBaseView];
    if (self.data) {
        self.amountTF.text = [NSString stringWithFormat:@"%@",self.data[k_Money_Key]];
        self.matterTV.text = self.data[k_Title_Key];
        self.amountTF.userInteractionEnabled = NO;
        self.matterTV.userInteractionEnabled = NO;
    }
}
- (void)layoutBaseView
{
    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(12, 12, Screen_Width - 24, 384)];
    topView.backgroundColor = [UIColor whiteColor];
    topView.layer.cornerRadius = 5.0f;
    topView.clipsToBounds = YES;
    [self.baseScrollView addSubview:topView];
    
    UIView *amountLine = [[UIView alloc] initWithFrame:CGRectMake(12, 17, 4, 12)];
    amountLine.backgroundColor = UIColorFromRGB(0xf8a20f);
    [topView addSubview:amountLine];
    
    UILabel *amountTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(25, 13, 200, 20)];
    amountTitleLab.text = @"消费价格";
    amountTitleLab.textColor = UIColorFromRGB(0x999999);
    amountTitleLab.font = [UIFont systemFontOfSize:15];
    [topView addSubview:amountTitleLab];
    
    self.amountTF = [[UITextField alloc] initWithFrame:CGRectMake(11, 36, topView.width - 22, 50)];
    _amountTF.layer.cornerRadius = 5.0f;
    _amountTF.clipsToBounds = YES;
    _amountTF.textAlignment = NSTextAlignmentCenter;
    UILabel *rightLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 25, 50)];
    rightLab.text = @"¥";
    rightLab.textColor = [UIColor blackColor];
    _amountTF.rightView = rightLab;
    _amountTF.rightViewMode = UITextFieldViewModeAlways;
    _amountTF.delegate = self;
    _amountTF.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    _amountTF.returnKeyType = UIReturnKeyDone;
    _amountTF.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [topView addSubview:_amountTF];
    
    UIView *matterLine = [[UIView alloc] initWithFrame:CGRectMake(12, 117, 4, 12)];
    matterLine.backgroundColor = UIColorFromRGB(0xf8a20f);
    [topView addSubview:matterLine];
    
    UILabel *matterTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(25, 113, 200, 20)];
    matterTitleLab.text = @"消费说明";
    matterTitleLab.textColor = UIColorFromRGB(0x999999);
    matterTitleLab.font = [UIFont systemFontOfSize:15];
    [topView addSubview:matterTitleLab];
    
    
    self.matterTV = [[UITextView alloc] initWithFrame:CGRectMake(11, 138, topView.width - 22, 233)];
    _matterTV.backgroundColor = [UIColor groupTableViewBackgroundColor];
    _matterTV.layer.cornerRadius = 5.0f;
    _matterTV.clipsToBounds = YES;
    _matterTV.delegate = self;
    [topView addSubview:_matterTV];
    
    if (!self.data) {
        UIButton *okBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        okBtn.frame = CGRectMake(12, 425, Screen_Width - 24, 50);
        okBtn.backgroundColor = Main_Color;
        [okBtn setTitle:@"OK" forState:UIControlStateNormal];
        [okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [okBtn addTarget:self action:@selector(okButtonCLick) forControlEvents:UIControlEventTouchUpInside];
        okBtn.layer.cornerRadius = 5.0f;
        okBtn.clipsToBounds = YES;
        okBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
        [self.baseScrollView addSubview:okBtn];
    }
    
    self.baseScrollView.contentSize = CGSizeMake(Screen_Width, 500);
    
}
- (void)okButtonCLick
{
    NSString *contentKey = @"";
    NSString *moneyKey = @"";
    NSString *maxKey = @"";
    NSString *dateKey = @"";
    if (self.memberType == FamliyMemberType_Grandfather) {
        contentKey = k_Content_Grandfather_Money;
        moneyKey = k_Total_Grandfather_Money;
        maxKey = k_Max_Grandfather_Money;
        dateKey = k_Date_Grandfather_Money;
    }else if (self.memberType == FamliyMemberType_Grandmother){
        contentKey = k_Content_Grandmother_Money;
        moneyKey = k_Total_Grandmother_Money;
        maxKey = k_Max_Grandmother_Money;
        dateKey = k_Date_Grandmother_Money;
    }else if (self.memberType == FamliyMemberType_Wife){
        contentKey = k_Content_Wife_Money;
        moneyKey = k_Total_Wife_Money;
        maxKey = k_Max_Wife_Money;
        dateKey = k_Date_Wife_Money;
    }else if (self.memberType == FamliyMemberType_Self){
        contentKey = k_Content_Self_Money;
        moneyKey = k_Total_Self_Money;
        maxKey = k_Max_Self_Money;
        dateKey = k_Date_Self_Money;
    }else if (self.memberType == FamliyMemberType_Baby){
        contentKey = k_Content_Baby_Money;
        moneyKey = k_Total_Baby_Money;
        maxKey = k_Max_Baby_Money;
        dateKey = k_Date_Baby_Money;
    }else if (self.memberType == FamliyMemberType_Others){
        contentKey = k_Content_Others_Money;
        moneyKey = k_Total_Others_Money;
        maxKey = k_Max_Others_Money;
        dateKey = k_Date_Others_Money;
    }
    NSArray *contentArray = [kNSUserDefaults objectForKey:contentKey];
    NSMutableArray *datas = [NSMutableArray arrayWithArray:contentArray];
    NSNumber *fValue = [kNSUserDefaults objectForKey:k_Total_Family_Money];
    NSNumber *tValue = [kNSUserDefaults objectForKey:moneyKey];
    NSNumber *maxValue = [kNSUserDefaults objectForKey:maxKey];
    float currentValue = [self.amountTF.text floatValue];
    if (currentValue > [maxValue floatValue]) {
        [kNSUserDefaults setObject:@(currentValue) forKey:maxKey];
    }
    float fV = [fValue floatValue] + currentValue;
    float tV = [tValue floatValue] + currentValue;
    [kNSUserDefaults setObject:@(fV) forKey:k_Total_Family_Money];
    [kNSUserDefaults setObject:@(tV) forKey:moneyKey];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setObject:@(currentValue) forKey:k_Money_Key];
    [dict setObject:self.matterTV.text forKey:k_Title_Key];
    [dict setObject:[NSDate getCurrentDate] forKey:k_Date_Key];
    [datas addObject:dict];
    [kNSUserDefaults setObject:datas forKey:contentKey];
    
    NSNumber *maxDateMoney = [kNSUserDefaults objectForKey:k_Max_Total_Money];
    NSNumber *minDateMoney = [kNSUserDefaults objectForKey:k_Min_Total_Money];
    
    NSMutableArray *dateValueArray = [NSMutableArray arrayWithArray:[kNSUserDefaults objectForKey:dateKey]];
    if (dateValueArray.count > 0) {
        NSMutableDictionary *lastDict = [NSMutableDictionary dictionaryWithDictionary:dateValueArray.lastObject];
        NSString *lastDateStr = lastDict[k_Today_Date_Key];
        if ([lastDateStr isEqualToString:[NSDate getCurrentDate]]) {
            NSNumber *lastValue = lastDict[k_Today_ToalMoney_Key];
            float todayValue = [lastValue floatValue] + currentValue;
            [lastDict setObject:@(todayValue) forKey:k_Today_ToalMoney_Key];
            if (maxDateMoney) {
                if (todayValue > [maxDateMoney floatValue]) {
                    [kNSUserDefaults setObject:@(todayValue) forKey:k_Max_Total_Money];
                    [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Max_Money_Date];
                }
            }else{
                [kNSUserDefaults setObject:@(todayValue) forKey:k_Max_Total_Money];
                [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Max_Money_Date];
            }
            if (minDateMoney) {
                if (todayValue < [minDateMoney floatValue]) {
                    [kNSUserDefaults setObject:@(todayValue) forKey:k_Min_Total_Money];
                    [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Min_Money_Date];
                }
            }else{
                [kNSUserDefaults setObject:@(todayValue) forKey:k_Min_Total_Money];
                [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Min_Money_Date];
            }
            
            
            [dateValueArray replaceObjectAtIndex:(dateValueArray.count - 1) withObject:lastDict];
        }else{
            NSMutableDictionary *newDayDict = [NSMutableDictionary dictionary];
            [newDayDict setObject:[NSDate getCurrentDate] forKey:k_Today_Date_Key];
            [newDayDict setObject:@(currentValue) forKey:k_Today_ToalMoney_Key];
            [dateValueArray addObject:newDayDict];
            if (maxDateMoney) {
                if (currentValue > [maxDateMoney floatValue]) {
                    [kNSUserDefaults setObject:@(currentValue) forKey:k_Max_Total_Money];
                    [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Max_Money_Date];
                }
            }else{
                [kNSUserDefaults setObject:@(currentValue) forKey:k_Max_Total_Money];
                [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Max_Money_Date];
            }
            if (minDateMoney) {
                if (currentValue < [minDateMoney floatValue]) {
                    [kNSUserDefaults setObject:@(currentValue) forKey:k_Min_Total_Money];
                    [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Min_Money_Date];
                }
            }else{
                [kNSUserDefaults setObject:@(currentValue) forKey:k_Min_Total_Money];
                [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Min_Money_Date];
            }
        }
    }else{
        NSMutableDictionary *newDayDict = [NSMutableDictionary dictionary];
        [newDayDict setObject:[NSDate getCurrentDate] forKey:k_Today_Date_Key];
        [newDayDict setObject:@(currentValue) forKey:k_Today_ToalMoney_Key];
        [dateValueArray addObject:newDayDict];
        if (maxDateMoney) {
            if (currentValue > [maxDateMoney floatValue]) {
                [kNSUserDefaults setObject:@(currentValue) forKey:k_Max_Total_Money];
                [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Max_Money_Date];
            }
        }else{
            [kNSUserDefaults setObject:@(currentValue) forKey:k_Max_Total_Money];
            [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Max_Money_Date];
        }
        if (minDateMoney) {
            if (currentValue < [minDateMoney floatValue]) {
                [kNSUserDefaults setObject:@(currentValue) forKey:k_Min_Total_Money];
                [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Min_Money_Date];
            }
        }else{
            [kNSUserDefaults setObject:@(currentValue) forKey:k_Min_Total_Money];
            [kNSUserDefaults setObject:[NSDate getCurrentYearAndDate] forKey:k_Min_Money_Date];
        }
    }
    [kNSUserDefaults setObject:dateValueArray forKey:dateKey];
    
    [kNSUserDefaults synchronize];
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([textField.text rangeOfString:@"."].location!= NSNotFound)
    {
        NSString *contentStr = [textField.text componentsSeparatedByString:@"."][1];
        if ([string isEqualToString:@"."])
        {
            return NO;
        }
        if (contentStr.length ==2 && string.length>0)
        {
            return NO;
        }
    }
    
    if (![NSString validateMath:string])
    {
        return NO;
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
@end
