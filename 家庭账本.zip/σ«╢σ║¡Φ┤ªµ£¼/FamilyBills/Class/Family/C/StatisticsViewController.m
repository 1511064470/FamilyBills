//
//  StatisticsViewController.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/19.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "StatisticsViewController.h"
#import "StatisticsCircleView.h"
#import "StatisticsLineView.h"
#import "CircleModel.h"
#import "ParentEmptyView.h"

@interface StatisticsViewController ()
{
    float currentY;
}
@property (nonatomic ,strong) UIScrollView *baseScrollView;
@property (nonatomic ,strong) StatisticsLineView *grandfatherLineView;
@property (nonatomic ,strong) UILabel *grandfatherTitleLab;
@property (nonatomic ,strong) UILabel *grandfatherMoneyLab;
@property (nonatomic ,strong) UIButton *grandfatherSelectBtn;
@property (nonatomic ,strong) UIView *grandfatherEmptyView;

@property (nonatomic ,strong) StatisticsLineView *wifeLineView;
@property (nonatomic ,strong) UILabel *wifeTitleLab;
@property (nonatomic ,strong) UILabel *wifeMoneyLab;
@property (nonatomic ,strong) UIButton *wifeSelectBtn;
@property (nonatomic ,strong) UIView *wifeEmptyView;

@property (nonatomic ,strong) StatisticsLineView *babyLineView;
@property (nonatomic ,strong) UILabel *babyTitleLab;
@property (nonatomic ,strong) UILabel *babyMoneyLab;
@property (nonatomic ,strong) UIButton *babySelectBtn;
@property (nonatomic ,strong) UIView *babyEmptyView;

@end

@implementation StatisticsViewController

- (UIScrollView *)baseScrollView
{
    if (!_baseScrollView) {
        _baseScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, Screen_Width, Screen_Height - 64)];
        _baseScrollView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        _baseScrollView.bounces = NO;
        [self.view addSubview:_baseScrollView];
    }
    return _baseScrollView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"统计";
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self layoutTopCircleView];
    [self layoutLineView];
}
- (void)layoutTopCircleView
{
    UIView *topCircleView = [[UIView alloc] initWithFrame:CGRectMake(12, 12, Screen_Width - 24, LineX(260))];
    topCircleView.layer.cornerRadius = 5.0f;
    topCircleView.clipsToBounds = YES;
    topCircleView.backgroundColor = [UIColor whiteColor];
    
    UILabel *totalTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 12, topCircleView.width, 21)];
    totalTitleLab.text = @"家庭总消费";
    totalTitleLab.textColor = UIColorFromRGB(0x999999);
    totalTitleLab.font = Font(15.0f);
    totalTitleLab.textAlignment = NSTextAlignmentCenter;
    [topCircleView addSubview:totalTitleLab];
    
    UILabel *totalValueLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 40, topCircleView.width, 30)];
    NSNumber *value = [kNSUserDefaults objectForKey:k_Total_Family_Money];
    totalValueLab.text = [NSString stringWithFormat:@"¥%.2f",[value floatValue]];
    totalValueLab.textColor = Main_Color;
    totalValueLab.font = Font(30.0f);
    totalValueLab.textAlignment = NSTextAlignmentCenter;
    [topCircleView addSubview:totalValueLab];
    
    
    StatisticsCircleView *circleView = [[StatisticsCircleView alloc] initWithCircleFrame:CGRectMake(0, 70 , topCircleView.width, LineH(190))];
    [topCircleView addSubview:circleView];
    
    [circleView showCircleViewWithDataSource:nil];
    
    
    [self.baseScrollView addSubview:topCircleView];
    currentY = 80 + LineH(190) + 12;
    
}
- (void)layoutLineView
{
    UIView *bottomView = [[UIView alloc] initWithFrame:CGRectMake(12, currentY, Screen_Width - 24, 1250)];
    bottomView.backgroundColor = [UIColor whiteColor];
    bottomView.layer.cornerRadius = 5.0f;
    bottomView.clipsToBounds = YES;
    [self.baseScrollView addSubview:bottomView];
    self.baseScrollView.contentSize = CGSizeMake(Screen_Width, 1300 + currentY);
    
    
    UILabel *yearLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 15 , bottomView.width, 20)];
    yearLab.text = [NSString stringWithFormat:@"<%@>",[NSDate getCurrentYear]];
    yearLab.textColor = UIColorFromRGB(0x666666);
    yearLab.font = Font(15.0);
    yearLab.textAlignment = NSTextAlignmentCenter;
    [bottomView addSubview:yearLab];
    
//***************************** Grandfather    ***********************************************
    UIButton *grandfatherBtn = [self createLineButtnTitle:@"爷爷"];
    grandfatherBtn.bounds = CGRectMake(0, 0, 130, 30);
    grandfatherBtn.selected = YES;
    grandfatherBtn.backgroundColor = Main_Color;
    grandfatherBtn.tag = 100;
    [grandfatherBtn addTarget:self action:@selector(seletGrandfatherClcik:) forControlEvents:UIControlEventTouchUpInside];
    self.grandfatherSelectBtn = grandfatherBtn;
    grandfatherBtn.center = CGPointMake(bottomView.width * 0.25, 70);
    [bottomView addSubview:grandfatherBtn];
    
    UIButton *grandmotherBtn = [self createLineButtnTitle:@"奶奶"];
    grandmotherBtn.bounds = CGRectMake(0, 0, 130, 30);
    grandmotherBtn.tag = 101;
    [grandmotherBtn addTarget:self action:@selector(seletGrandfatherClcik:) forControlEvents:UIControlEventTouchUpInside];
    grandmotherBtn.center = CGPointMake(bottomView.width * 0.75, 70);
    [bottomView addSubview:grandmotherBtn];
    
    self.grandfatherTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 112, bottomView.width, 20)];
    _grandfatherTitleLab.text = @"爷爷总消费";
    _grandfatherTitleLab.textColor = UIColorFromRGB(0x999999);
    _grandfatherTitleLab.textAlignment = NSTextAlignmentCenter;
    _grandfatherTitleLab.font = [UIFont systemFontOfSize:15.0f];
    [bottomView addSubview:_grandfatherTitleLab];
    
    self.grandfatherMoneyLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 140, bottomView.width, 20)];
    NSNumber *grandfatherNumber = [kNSUserDefaults objectForKey:k_Total_Grandfather_Money] ? : @(0.00);
    _grandfatherMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",grandfatherNumber.floatValue];
    _grandfatherMoneyLab.textColor = Main_Color;
    _grandfatherMoneyLab.textAlignment = NSTextAlignmentCenter;
    _grandfatherMoneyLab.font = [UIFont systemFontOfSize:22.0f];
    [bottomView addSubview:_grandfatherMoneyLab];
    
    
    NSArray *source = [kNSUserDefaults objectForKey:k_Date_Grandfather_Money];
    CGFloat max = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
    self.grandfatherLineView = [[StatisticsLineView alloc] initWithFrame:CGRectMake(12, 160, bottomView.width - 24, 250) chartViewType:LCChartViewTypeBar];
    [_grandfatherLineView showChartViewWithYAxisMaxValue:max dataSource:source];
    [bottomView addSubview:_grandfatherLineView];
    
    self.grandfatherEmptyView = [[UIView alloc] initWithFrame:CGRectMake(0, 160, bottomView.width, 250)];
    _grandfatherEmptyView.backgroundColor = [UIColor whiteColor];
    _grandfatherEmptyView.hidden = source.count > 0 ? YES :NO;
    ParentEmptyView *gv = [ParentEmptyView emptyView];
    gv.bounds = CGRectMake(0, 0, bottomView.width, 71);
    gv.center = CGPointMake(bottomView.width * 0.5,125);
    gv.titleLab.text = @"目前没有消费！";
    [_grandfatherEmptyView addSubview:gv];
    [bottomView addSubview:_grandfatherEmptyView];
    
//***************************** Wife  410 + 45   ***********************************************

    
    
    UIButton *wifeBtn = [self createLineButtnTitle:@"妻子"];
    wifeBtn.bounds = CGRectMake(0, 0, 130, 30);
    wifeBtn.selected = YES;
    wifeBtn.backgroundColor = Main_Color;
    wifeBtn.tag = 100;
    [wifeBtn addTarget:self action:@selector(seletWifeClcik:) forControlEvents:UIControlEventTouchUpInside];
    self.wifeSelectBtn = wifeBtn;
    wifeBtn.center = CGPointMake(bottomView.width * 0.25, 470);
    [bottomView addSubview:wifeBtn];
    
    UIButton *selfBtn = [self createLineButtnTitle:@"丈夫"];
    selfBtn.bounds = CGRectMake(0, 0, 130, 30);
    selfBtn.tag = 101;
    [selfBtn addTarget:self action:@selector(seletWifeClcik:) forControlEvents:UIControlEventTouchUpInside];
    selfBtn.center = CGPointMake(bottomView.width * 0.75, 470);
    [bottomView addSubview:selfBtn];
    
    self.wifeTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 512, bottomView.width, 20)];
    _wifeTitleLab.text = @"妻子总消费";
    _wifeTitleLab.textColor = UIColorFromRGB(0x999999);
    _wifeTitleLab.textAlignment = NSTextAlignmentCenter;
    _wifeTitleLab.font = [UIFont systemFontOfSize:15.0f];
    [bottomView addSubview:_wifeTitleLab];
    
    self.wifeMoneyLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 540, bottomView.width, 20)];
    NSNumber *wifeNumber = [kNSUserDefaults objectForKey:k_Total_Wife_Money] ? : @(0);
    _wifeMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",wifeNumber.floatValue];
    _wifeMoneyLab.textColor = Main_Color;
    _wifeMoneyLab.textAlignment = NSTextAlignmentCenter;
    _wifeMoneyLab.font = [UIFont systemFontOfSize:22.0f];
    [bottomView addSubview:_wifeMoneyLab];
    
    
    NSArray *wifeSource = [kNSUserDefaults objectForKey:k_Date_Wife_Money];
    CGFloat wifeMax = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
    self.wifeLineView = [[StatisticsLineView alloc] initWithFrame:CGRectMake(12, 560, bottomView.width - 24, 250) chartViewType:LCChartViewTypeBar];
    [_wifeLineView showChartViewWithYAxisMaxValue:wifeMax dataSource:wifeSource];
    [bottomView addSubview:_wifeLineView];
    
    self.wifeEmptyView = [[UIView alloc] initWithFrame:CGRectMake(0, 560, bottomView.width, 250)];
    _wifeEmptyView.backgroundColor = [UIColor whiteColor];
    _wifeEmptyView.hidden = wifeSource.count > 0 ? YES :NO;
    ParentEmptyView *wv = [ParentEmptyView emptyView];
    wv.bounds = CGRectMake(0, 0, bottomView.width, 71);
    wv.center = CGPointMake(bottomView.width * 0.5,125);
    wv.titleLab.text = @"目前没有消费！";
    [_wifeEmptyView addSubview:wv];
    [bottomView addSubview:_wifeEmptyView];
    
    
//***************************** baby  810 + 45   ***********************************************
    
    UIButton *babyBtn = [self createLineButtnTitle:@"孩子"];
    babyBtn.bounds = CGRectMake(0, 0, 130, 30);
    babyBtn.selected = YES;
    babyBtn.backgroundColor = Main_Color;
    babyBtn.tag = 100;
    [babyBtn addTarget:self action:@selector(seletBabyClcik:) forControlEvents:UIControlEventTouchUpInside];
    self.babySelectBtn = babyBtn;
    babyBtn.center = CGPointMake(bottomView.width * 0.25, 870);
    [bottomView addSubview:babyBtn];
    
    UIButton *othersBtn = [self createLineButtnTitle:@"其他"];
    othersBtn.bounds = CGRectMake(0, 0, 130, 30);
    othersBtn.tag = 101;
    [othersBtn addTarget:self action:@selector(seletBabyClcik:) forControlEvents:UIControlEventTouchUpInside];
    othersBtn.center = CGPointMake(bottomView.width * 0.75, 870);
    [bottomView addSubview:othersBtn];
    
    self.babyTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 912, bottomView.width, 20)];
    _babyTitleLab.text = @"孩子总消费";
    _babyTitleLab.textColor = UIColorFromRGB(0x999999);
    _babyTitleLab.textAlignment = NSTextAlignmentCenter;
    _babyTitleLab.font = [UIFont systemFontOfSize:15.0f];
    [bottomView addSubview:_babyTitleLab];
    
    self.babyMoneyLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 940, bottomView.width, 20)];
    NSNumber *babyNumber = [kNSUserDefaults objectForKey:k_Total_Baby_Money] ? : @(0);
    _babyMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",babyNumber.floatValue];
    _babyMoneyLab.textColor = Main_Color;
    _babyMoneyLab.textAlignment = NSTextAlignmentCenter;
    _babyMoneyLab.font = [UIFont systemFontOfSize:22.0f];
    [bottomView addSubview:_babyMoneyLab];
    
    
    NSArray *babySource = [kNSUserDefaults objectForKey:k_Date_Baby_Money];
    CGFloat babyMax = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
    self.babyLineView = [[StatisticsLineView alloc] initWithFrame:CGRectMake(12, 960, bottomView.width - 24, 250) chartViewType:LCChartViewTypeBar];
    [_babyLineView showChartViewWithYAxisMaxValue:babyMax dataSource:babySource];
    [bottomView addSubview:_babyLineView];
    
    self.babyEmptyView = [[UIView alloc] initWithFrame:CGRectMake(0, 960, bottomView.width, 250)];
    _babyEmptyView.backgroundColor = [UIColor whiteColor];
    _babyEmptyView.hidden = babySource.count > 0 ? YES :NO;
    ParentEmptyView *bv = [ParentEmptyView emptyView];
    bv.bounds = CGRectMake(0, 0, bottomView.width, 71);
    bv.center = CGPointMake(bottomView.width * 0.5,125);
    bv.titleLab.text = @"目前没有消费！";
    [_babyEmptyView addSubview:bv];
    [bottomView addSubview:_babyEmptyView];
    
//************************ minAndMaxView ***************************************************************
    UIView *minAndMaxView = [[UIView alloc] initWithFrame:CGRectMake(12,currentY + 1260, Screen_Width - 24, 84)];
    minAndMaxView.backgroundColor = [UIColor whiteColor];
    minAndMaxView.layer.cornerRadius = 5.0f;
    minAndMaxView.clipsToBounds = YES;
    [self.baseScrollView addSubview:minAndMaxView];
    
    NSArray *maxAndMinValue = [CircleModel getMaxAndMinValue];
    
    NSString *maxDateStr = [kNSUserDefaults objectForKey:k_Max_Money_Date] ? : @"--";
    UILabel *maxTitleLab = [[UILabel alloc] init];
    if ([CircleModel getIsIpad]) {
        maxTitleLab.frame = CGRectMake(15, 0, 215, 42);
        maxTitleLab.font = [UIFont systemFontOfSize:12.0f];
    }else{
        maxTitleLab.frame = CGRectMake(15, 0, 250, 42);
        maxTitleLab.font = [UIFont systemFontOfSize:15.0f];
    }
    maxTitleLab.text = [NSString stringWithFormat:@"%@ 最高消费记录:",maxDateStr];
    maxTitleLab.textColor = UIColorFromRGB(0x999999);
    [minAndMaxView addSubview:maxTitleLab];
    
    UILabel *maxMoneyLab = [[UILabel alloc] init];
    if ([CircleModel getIsIpad]) {
        maxMoneyLab.frame = CGRectMake(230, 0, minAndMaxView.width - 230, 42);
        maxMoneyLab.font = [UIFont systemFontOfSize:12.0f];
    }else{
        maxMoneyLab.frame = CGRectMake(265, 0, minAndMaxView.width - 265, 42);
        maxMoneyLab.font = [UIFont systemFontOfSize:15.0f];
    }
    NSNumber *maxMoneyNum = maxAndMinValue[0];
    maxMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",maxMoneyNum.floatValue];
    maxMoneyLab.textColor = Main_Color;
    [minAndMaxView addSubview:maxMoneyLab];
    
    NSString *minDateStr = [kNSUserDefaults objectForKey:k_Min_Money_Date] ? : @"--";
    UILabel *minTitleLab = [[UILabel alloc] init];
    if ([CircleModel getIsIpad]) {
        minTitleLab.frame = CGRectMake(15, 42, 215, 42);
        minTitleLab.font = [UIFont systemFontOfSize:12.0f];
    }else{
        minTitleLab.frame = CGRectMake(15, 42, 250, 42);
        minTitleLab.font = [UIFont systemFontOfSize:15.0f];
    }
    minTitleLab.text = [NSString stringWithFormat:@"%@ 最低消费记录:",minDateStr];
    minTitleLab.textColor = UIColorFromRGB(0x999999);
    [minAndMaxView addSubview:minTitleLab];
    
    UILabel *minMoneyLab = [[UILabel alloc] init];
    if ([CircleModel getIsIpad]) {
        minMoneyLab.frame = CGRectMake(230, 42, minAndMaxView.width - 230, 42);
        minMoneyLab.font = [UIFont systemFontOfSize:12.0f];
    }else{
        minMoneyLab.frame = CGRectMake(265, 42, minAndMaxView.width - 265, 42);
        minMoneyLab.font = [UIFont systemFontOfSize:15.0f];
    }
    NSNumber *minMoneyNum = maxAndMinValue[1];
    minMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",minMoneyNum.floatValue];
    minMoneyLab.textColor = Main_Color;
    [minAndMaxView addSubview:minMoneyLab];
    
    self.baseScrollView.contentSize = CGSizeMake(Screen_Width, 1360 + currentY);
}


- (void)seletGrandfatherClcik:(UIButton *)button
{
    if (button != self.grandfatherSelectBtn) {
        self.grandfatherSelectBtn.backgroundColor = [UIColor whiteColor];
        self.grandfatherSelectBtn.selected = NO;
        button.backgroundColor = Main_Color;
        button.selected = YES;
        self.grandfatherSelectBtn = button;
        
        if (button.tag == 100) {
            self.grandfatherTitleLab.text = @"爷爷总消费";
            NSNumber *number = [kNSUserDefaults objectForKey:k_Total_Grandfather_Money] ? : @(0);
            self.grandfatherMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",number.floatValue];
            NSArray *source = [kNSUserDefaults objectForKey:k_Date_Grandfather_Money];
            CGFloat max = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
            if (source.count > 0) {
                self.grandfatherEmptyView.hidden = YES;
                [_grandfatherLineView showChartViewWithYAxisMaxValue:max dataSource:source];
            }else{
                self.grandfatherEmptyView.hidden = NO;
            }
            
        }else{
            self.grandfatherTitleLab.text = @"奶奶总消费";
            NSNumber *number = [kNSUserDefaults objectForKey:k_Total_Grandmother_Money] ? : @(0);
            self.grandfatherMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",number.floatValue];
            NSArray *source = [kNSUserDefaults objectForKey:k_Date_Grandmother_Money];
            CGFloat max = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
            if (source.count > 0) {
                self.grandfatherEmptyView.hidden = YES;
                [_grandfatherLineView showChartViewWithYAxisMaxValue:max dataSource:source];
            }else{
                self.grandfatherEmptyView.hidden = NO;
            }
        }
    }
}
- (void)seletWifeClcik:(UIButton *)button
{
    if (button != self.wifeSelectBtn) {
        self.wifeSelectBtn.backgroundColor = [UIColor whiteColor];
        self.wifeSelectBtn.selected = NO;
        button.backgroundColor = Main_Color;
        button.selected = YES;
        self.wifeSelectBtn = button;
        if (button.tag == 100) {
            self.wifeTitleLab.text = @"妻子总消费";
            NSNumber *number = [kNSUserDefaults objectForKey:k_Total_Wife_Money] ? : @(0);
            self.wifeMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",number.floatValue];
            NSArray *source = [kNSUserDefaults objectForKey:k_Date_Wife_Money];
            CGFloat max = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
            if (source.count > 0) {
                self.wifeEmptyView.hidden = YES;
                [_wifeLineView showChartViewWithYAxisMaxValue:max dataSource:source];
            }else{
                self.wifeEmptyView.hidden = NO;
            }
            
            
        }else{
            self.wifeTitleLab.text = @"丈夫总消费";
            NSNumber *number = [kNSUserDefaults objectForKey:k_Total_Self_Money] ? : @(0);
            self.wifeMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",number.floatValue];
            NSArray *source = [kNSUserDefaults objectForKey:k_Date_Self_Money];
            CGFloat max = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
            if (source.count > 0) {
                self.wifeEmptyView.hidden = YES;
                [_wifeLineView showChartViewWithYAxisMaxValue:max dataSource:source];
            }else{
                self.wifeEmptyView.hidden = NO;
            }
        }
    }
}
- (void)seletBabyClcik:(UIButton *)button
{
    if (button != self.babySelectBtn) {
        self.babySelectBtn.backgroundColor = [UIColor whiteColor];
        self.babySelectBtn.selected = NO;
        button.backgroundColor = Main_Color;
        button.selected = YES;
        self.babySelectBtn = button;
        if (button.tag == 100) {
            self.babyTitleLab.text = @"孩子总消费";
            NSNumber *number = [kNSUserDefaults objectForKey:k_Total_Baby_Money] ? : @(0);
            self.babyMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",number.floatValue];
            NSArray *source = [kNSUserDefaults objectForKey:k_Date_Baby_Money];
            CGFloat max = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
            if (source.count > 0) {
                self.babyEmptyView.hidden = YES;
                [_babyLineView showChartViewWithYAxisMaxValue:max dataSource:source];
            }else{
                self.babyEmptyView.hidden = NO;
            }
            
        }else{
            self.babyTitleLab.text = @"其他总消费";
            NSNumber *number = [kNSUserDefaults objectForKey:k_Total_Others_Money] ? : @(0);
            self.babyMoneyLab.text = [NSString stringWithFormat:@"¥%.2f",number.floatValue];
            NSArray *source = [kNSUserDefaults objectForKey:k_Date_Others_Money];
            CGFloat max = [[kNSUserDefaults objectForKey:k_Max_Total_Money] floatValue];
            if (source.count > 0) {
                self.babyEmptyView.hidden = YES;
                [_babyLineView showChartViewWithYAxisMaxValue:max dataSource:source];
            }else{
                self.babyEmptyView.hidden = NO;
            }
        }
    }
}
- (UIButton *)createLineButtnTitle:(NSString *)title
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    button.layer.cornerRadius = 5.0f;
    button.clipsToBounds = YES;
    button.layer.borderColor = Main_Color.CGColor;
    button.layer.borderWidth = 1.0f;
    button.titleLabel.font = [UIFont systemFontOfSize:15];
    button.backgroundColor = [UIColor whiteColor];
    [button setTitleColor:Main_Color forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    return button;
}

@end
