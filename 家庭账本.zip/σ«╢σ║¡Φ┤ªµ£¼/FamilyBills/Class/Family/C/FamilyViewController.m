//
//  FamilyViewController.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/19.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "FamilyViewController.h"
#import "TotalConsumptionView.h"
#import "FamilyMembersView.h"
#import "ListTableViewCell.h"
#import "StatisticsViewController.h"
#import "GrandfatherViewController.h"
#import "ParentEmptyView.h"

@interface FamilyViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    float CurrentY;
}
@property (nonatomic ,strong) TotalConsumptionView *houseTotalView;
@property (nonatomic ,strong) TotalConsumptionView *membersToalView;
@property (nonatomic ,strong) FamilyMembersView *membersView;
@property (nonatomic ,strong) UIView *baseView;
@property (nonatomic ,strong) UITableView *listTableView;
@property (nonatomic ,strong) NSMutableArray *dataArray;
@property (nonatomic ,assign) FamliyMemberType currentMember;
@property (nonatomic ,strong) ParentEmptyView *emptyView;
@property (nonatomic ,copy) NSString *currentContentKey;
@end

@implementation FamilyViewController
static NSString * const ListTableCell = @"ListTableCell";

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self selectedMember:self.currentMember];
    NSNumber *value = [kNSUserDefaults objectForKey:k_Total_Family_Money];
    [_houseTotalView updateTotalValue:@"家庭总消费" WithValue:value];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"家庭账本";
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self isHiddeNavigationTabBar:NO];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"统计" style:UIBarButtonItemStylePlain target:self action:@selector(StatisticsButtonClick)];
    NSString *deviceType = [UIDevice currentDevice].model;
    if([deviceType isEqualToString:@"iPad"]){
        [self.navigationItem.rightBarButtonItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:12],NSFontAttributeName, nil] forState:UIControlStateNormal];
    }
    
    
    [self.dataArray addObjectsFromArray:[kNSUserDefaults objectForKey:k_Content_Grandfather_Money]];
    self.currentMember = FamliyMemberType_Grandfather;
    [self layoutTopToalHouseholdConsumptionView];
    [self layoutFamilyMembersView];
    [self layoutYearView];
    [self layoutToalMembersConsumptionView];
    [self layoutTableView];
    [self layouAddNewList];
}
- (void)StatisticsButtonClick
{
    StatisticsViewController *VC = [[StatisticsViewController alloc] init];
    [self.navigationController pushViewController:VC animated:YES];
}
#pragma mark 加载houseTotalView
- (void)layoutTopToalHouseholdConsumptionView
{
    self.houseTotalView = [[TotalConsumptionView alloc] initWithTotalConsumptionViewFrame:CGRectMake(12, 76, Screen_Width - 24, LineX(88))];
    [self.view addSubview:_houseTotalView];
}
#pragma mark 加载membersView
- (void)layoutFamilyMembersView
{
    self.baseView = [[UIView alloc] initWithFrame:CGRectMake(0, LineX(88) + 86, Screen_Width, Screen_Height - LineX(88) - 86)];
    _baseView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_baseView];
    
    self.membersView = [[FamilyMembersView alloc] initWithFamilyMembersViewFrame:CGRectMake(0, 0, Screen_Width, 53)];
    [self.baseView addSubview:_membersView];
    MJWeakSelf;
    _membersView.familyMembersSelectBlock = ^(NSInteger number) {
        [weakSelf selectedMember:number];
    };
    CurrentY = 54;
}
- (void)selectedMember:(NSInteger)number
{
    NSNumber *value = @(0);
    NSString *title = @"";
    [self.dataArray removeAllObjects];
    if (number == 0) {//grandfather
        value = [kNSUserDefaults objectForKey:k_Total_Grandfather_Money];
        title = @"爷爷总消费";
        self.currentContentKey = k_Content_Grandfather_Money;
        [self.dataArray addObjectsFromArray:[kNSUserDefaults objectForKey:k_Content_Grandfather_Money]];
        self.currentMember = FamliyMemberType_Grandfather;
    }else if (number == 1){//grandmother
        value = [kNSUserDefaults objectForKey:k_Total_Grandmother_Money];
        title = @"奶奶总消费";
        self.currentContentKey = k_Content_Grandmother_Money;
        [self.dataArray addObjectsFromArray:[kNSUserDefaults objectForKey:k_Content_Grandmother_Money]];
        self.currentMember = FamliyMemberType_Grandmother;
    }else if (number == 2){//wife
        value = [kNSUserDefaults objectForKey:k_Total_Wife_Money];
        title = @"妻子总消费";
        self.currentContentKey = k_Content_Wife_Money;
        [self.dataArray addObjectsFromArray:[kNSUserDefaults objectForKey:k_Content_Wife_Money]];
        self.currentMember = FamliyMemberType_Wife;
    }else if (number == 3){//self
        value = [kNSUserDefaults objectForKey:k_Total_Self_Money];
        title = @"丈夫总消费";
        self.currentContentKey = k_Content_Self_Money;
        [self.dataArray addObjectsFromArray:[kNSUserDefaults objectForKey:k_Content_Self_Money]];
        self.currentMember = FamliyMemberType_Self;
    }else if (number == 4){//baby
        value = [kNSUserDefaults objectForKey:k_Total_Baby_Money];
        title = @"孩子总消费";
        self.currentContentKey = k_Content_Baby_Money;
        [self.dataArray addObjectsFromArray:[kNSUserDefaults objectForKey:k_Content_Baby_Money]];
        self.currentMember = FamliyMemberType_Baby;
    }else if (number == 5){//others
        value = [kNSUserDefaults objectForKey:k_Total_Others_Money];
        title = @"其他总消费";
        self.currentContentKey = k_Content_Others_Money;
        [self.dataArray addObjectsFromArray:[kNSUserDefaults objectForKey:k_Content_Others_Money]];
        self.currentMember = FamliyMemberType_Others;
    }
    [_membersToalView updateTotalValue:title WithValue:value];
    if (self.dataArray.count == 0) {
        self.emptyView.hidden = NO;
    }else{
        self.emptyView.hidden = YES;
    }
    [self.listTableView reloadData];

}
#pragma mark 加载yearLab
- (void)layoutYearView
{
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(12, CurrentY , Screen_Width - 24, 1)];
    lineView.backgroundColor = UIColorFromRGB(0xececec);
    [self.baseView addSubview:lineView];
    
    UILabel *yearLab = [[UILabel alloc] initWithFrame:CGRectMake(0, CurrentY +1 , Screen_Width, 38)];
    yearLab.text = [NSString stringWithFormat:@"<%@>",[NSDate getCurrentYear]];
    yearLab.textColor = UIColorFromRGB(0x666666);
    yearLab.font = Font(15.0);
    yearLab.textAlignment = NSTextAlignmentCenter;
    [self.baseView addSubview:yearLab];
    CurrentY = CurrentY + 40;
}
#pragma mark 加载membersToalView
- (void)layoutToalMembersConsumptionView
{
    self.membersToalView = [[TotalConsumptionView alloc] initWithTotalConsumptionViewFrame:CGRectMake(12, CurrentY, Screen_Width - 24, LineX(88))];
    _membersToalView.layer.borderColor = UIColorFromRGB(0xececec).CGColor;
    _membersToalView.layer.borderWidth = 1;
    [self.baseView addSubview:_membersToalView];
    NSNumber *value = [kNSUserDefaults objectForKey:k_Total_Grandfather_Money];
    [_membersToalView updateTotalValue:@"爷爷总消费" WithValue:value];

    CurrentY = CurrentY + LineX(88);
}
#pragma mark 加载UITableView
- (void)layoutTableView
{
    _listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,CurrentY, Screen_Width,_baseView.height - CurrentY)];
    _listTableView.delegate = self;
    _listTableView.dataSource = self;
//    _listTableView.backgroundColor = UIColorFromRGB(0xf0f0f0);
    _listTableView.showsVerticalScrollIndicator = NO;
    _listTableView.rowHeight = 75;
    [_listTableView registerNib:[UINib nibWithNibName:@"ListTableViewCell" bundle:nil] forCellReuseIdentifier:ListTableCell];
    _listTableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screen_Width, 80)];
    _listTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.baseView addSubview:_listTableView];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ListTableCell forIndexPath:indexPath];
    if (indexPath.row == 0) {
        cell.topLineView.hidden = YES;
    }else{
        cell.topLineView.hidden = NO;
    }
    cell.data = self.dataArray[indexPath.row];
    [cell.deleteBtn addTarget:self action:@selector(deleteListButtonCLick:) forControlEvents:UIControlEventTouchUpInside];
    cell.deleteBtn.tag = indexPath.row;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    GrandfatherViewController *VC = [[GrandfatherViewController alloc] init];
    VC.memberType = self.currentMember;
    VC.data = self.dataArray[indexPath.row];
    [self.navigationController pushViewController:VC animated:YES];
}
- (void)deleteListButtonCLick:(UIButton *)button
{
    UIAlertController *alter = [UIAlertController alertControllerWithTitle:@"" message:@"确定要删除这个记录么？" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self updateUserInfoValueWith:button.tag];
        
    }];
    [alter addAction:action1];
    [alter addAction:action2];
    [self presentViewController:alter animated:YES completion:nil];
}
- (void)updateUserInfoValueWith:(NSInteger)number
{
    NSString *contentKey = @"";
    NSString *moneyKey = @"";
    NSString *dateKey = @"";
    if (self.currentMember == FamliyMemberType_Grandfather) {
        contentKey = k_Content_Grandfather_Money;
        moneyKey = k_Total_Grandfather_Money;
        dateKey = k_Date_Grandfather_Money;
    }else if (self.currentMember == FamliyMemberType_Grandmother){
        contentKey = k_Content_Grandmother_Money;
        moneyKey = k_Total_Grandmother_Money;
        dateKey = k_Date_Grandmother_Money;
    }else if (self.currentMember == FamliyMemberType_Wife){
        contentKey = k_Content_Wife_Money;
        moneyKey = k_Total_Wife_Money;
        dateKey = k_Date_Wife_Money;
    }else if (self.currentMember == FamliyMemberType_Self){
        contentKey = k_Content_Self_Money;
        moneyKey = k_Total_Self_Money;
        dateKey = k_Date_Self_Money;
    }else if (self.currentMember == FamliyMemberType_Baby){
        contentKey = k_Content_Baby_Money;
        moneyKey = k_Total_Baby_Money;
        dateKey = k_Date_Baby_Money;
    }else if (self.currentMember == FamliyMemberType_Others){
        contentKey = k_Content_Others_Money;
        moneyKey = k_Total_Others_Money;
        dateKey = k_Date_Others_Money;
    }
    NSDictionary *dict = self.dataArray[number];
    float currentValue = [dict[k_Money_Key] floatValue];
    NSString *deleteDateStr = dict[k_Date_Key];
    
    NSNumber *fValue = [kNSUserDefaults objectForKey:k_Total_Family_Money];
    NSNumber *tValue = [kNSUserDefaults objectForKey:moneyKey];
    
    float fV = [fValue floatValue] - currentValue;
    float tV = [tValue floatValue] - currentValue;
    [kNSUserDefaults setObject:@(fV) forKey:k_Total_Family_Money];
    [kNSUserDefaults setObject:@(tV) forKey:moneyKey];
    
    NSMutableArray *dateValueArray = [NSMutableArray arrayWithArray:[kNSUserDefaults objectForKey:dateKey]];
    if (dateValueArray.count > 0) {
        
        for (int i =0 ; i < dateValueArray.count; i++) {
            NSDictionary *dateValueDict = dateValueArray[i];
            NSString *lastDateStr = dateValueDict[k_Today_Date_Key];
            if ([lastDateStr isEqualToString:deleteDateStr]) {
                
                NSNumber *lastValue = dateValueDict[k_Today_ToalMoney_Key];
                float todayValue = [lastValue floatValue] - currentValue;
                
                if (todayValue == 0) {
                    [dateValueArray removeObjectAtIndex:i];
                }else{
                    NSMutableDictionary *newDayDict = [NSMutableDictionary dictionary];
                    [newDayDict setObject:lastDateStr forKey:k_Today_Date_Key];
                    [newDayDict setObject:@(todayValue) forKey:k_Today_ToalMoney_Key];
                    [dateValueArray replaceObjectAtIndex:i withObject:newDayDict];
                }
            }
        }
    }
    [kNSUserDefaults setObject:dateValueArray forKey:dateKey];
    
    [self.dataArray removeObjectAtIndex:number];
    [kNSUserDefaults setObject:self.dataArray forKey:contentKey];
    
    [kNSUserDefaults synchronize];
    
    [self selectedMember:self.currentMember];
    NSNumber *value = [kNSUserDefaults objectForKey:k_Total_Family_Money];
    [_houseTotalView updateTotalValue:@"家庭总消费" WithValue:value];
    
}
- (void)layouAddNewList
{
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    addBtn.frame = CGRectMake(Screen_Width - 72, self.baseView.height - 52, 60, 40);
    addBtn.layer.borderColor = Main_Color.CGColor;
    addBtn.layer.borderWidth = 1.0f;
    addBtn.layer.cornerRadius = 5.0f;
    addBtn.clipsToBounds = YES;
    addBtn.backgroundColor = [UIColor whiteColor];
    [addBtn setTitle:@"Add" forState:UIControlStateNormal];
    [addBtn setTitleColor:Main_Color forState:UIControlStateNormal];
    [addBtn addTarget:self action:@selector(addNewList) forControlEvents:UIControlEventTouchUpInside];
    [self.baseView addSubview:addBtn];
}
- (void)addNewList
{
    GrandfatherViewController *VC = [[GrandfatherViewController alloc] init];
    VC.memberType = self.currentMember;
    [self.navigationController pushViewController:VC animated:YES];
}
#pragma mark 加载EmptyView
- (ParentEmptyView *)emptyView
{
    if (!_emptyView)
    {
        _emptyView = [ParentEmptyView emptyView];
        _emptyView.bounds = CGRectMake(0, 0, Screen_Width, 71);
        _emptyView.center = CGPointMake(Screen_Width * 0.5, (_baseView.height - CurrentY) * 0.5 - 20 + CurrentY);
        _emptyView.titleLab.text = @"目前还没有记录！";
        [self.baseView addSubview:_emptyView];
    }
    return _emptyView;
}
@end
