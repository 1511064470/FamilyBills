//
//  CircleModel.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "CircleModel.h"

@implementation CircleModel

+ (instancetype)modelWithColor:(UIColor *)color plots:(NSArray<NSString *> *)plots project:(NSString *)project {
    CircleModel *model = [[self alloc] init];
    model.color = color;
    model.project = project;
    model.plots = plots;
    return model;
}

- (void)setData:(NSDictionary *)data
{
    _data = data;
    self.color = _data[@"color"];
    self.value = [_data[@"value"] floatValue];
    self.text = _data[@"title"];
}
+ (CGSize)sizeWithText:(NSString *)text fontSize:(CGFloat)fontSize {
    NSDictionary *attr = @{NSFontAttributeName : [UIFont systemFontOfSize:fontSize]};
    return [text sizeWithAttributes:attr];
}

+ (UIImage *)imageFromColor:(UIColor *)color rect:(CGRect)rect{
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

+ (CAShapeLayer *)shapeLayerWithPath:(UIBezierPath *)path lineWidth:(CGFloat)lineWidth fillColor:(UIColor *)fillColor strokeColor:(UIColor *)strokeColor {
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.lineWidth = lineWidth;
    shapeLayer.fillColor = fillColor.CGColor;
    shapeLayer.strokeColor = strokeColor.CGColor;
    shapeLayer.lineCap = kCALineCapButt;
    shapeLayer.lineJoin = kCALineJoinBevel;
    shapeLayer.path = path.CGPath;
    return shapeLayer;
}
+ (BOOL)getIsIpad
{
    NSString *deviceType = [UIDevice currentDevice].model;
    
    if([deviceType isEqualToString:@"iPhone"]) {
        //iPhone
        return NO;
    }else if([deviceType isEqualToString:@"iPod touch"]) {
        //iPod Touch
        return NO;
    }else if([deviceType isEqualToString:@"iPad"]) {
        //iPad
        return YES;
    }
    return NO;
}
+ (NSArray *)getMaxAndMinValue
{
    float maxValue = 0.00;
    float minValue = 0.00;
    NSArray *fSource = [kNSUserDefaults objectForKey:k_Date_Grandfather_Money];
    NSArray *mSource = [kNSUserDefaults objectForKey:k_Date_Grandmother_Money];
    NSArray *wSource = [kNSUserDefaults objectForKey:k_Date_Wife_Money];
    NSArray *sSource = [kNSUserDefaults objectForKey:k_Date_Self_Money];
    NSArray *bSource = [kNSUserDefaults objectForKey:k_Date_Baby_Money];
    NSArray *oSource = [kNSUserDefaults objectForKey:k_Date_Others_Money];
    if (fSource.count > 0) {
        for (NSDictionary *dict in fSource) {
            NSNumber *dateValue = dict[k_Today_ToalMoney_Key];
            if ([dateValue floatValue] > maxValue) {
                maxValue = [dateValue floatValue];
            }
            if (minValue == 0.00) {
                minValue = [dateValue floatValue];
            }else{
                if ([dateValue floatValue] < minValue) {
                    minValue = [dateValue floatValue];
                }
            }
            
        }
    }
    if (mSource.count > 0) {
        for (NSDictionary *dict in mSource) {
            NSNumber *dateValue = dict[k_Today_ToalMoney_Key];
            if ([dateValue floatValue] > maxValue) {
                maxValue = [dateValue floatValue];
            }
            if (minValue == 0.00) {
                minValue = [dateValue floatValue];
            }else{
                if ([dateValue floatValue] < minValue) {
                    minValue = [dateValue floatValue];
                }
            }
        }
    }
    if (wSource.count > 0) {
        for (NSDictionary *dict in wSource) {
            NSNumber *dateValue = dict[k_Today_ToalMoney_Key];
            if ([dateValue floatValue] > maxValue) {
                maxValue = [dateValue floatValue];
            }
            if (minValue == 0.00) {
                minValue = [dateValue floatValue];
            }else{
                if ([dateValue floatValue] < minValue) {
                    minValue = [dateValue floatValue];
                }
            }
        }
    }
    if (sSource.count > 0) {
        for (NSDictionary *dict in sSource) {
            NSNumber *dateValue = dict[k_Today_ToalMoney_Key];
            if ([dateValue floatValue] > maxValue) {
                maxValue = [dateValue floatValue];
            }
            if (minValue == 0.00) {
                minValue = [dateValue floatValue];
            }else{
                if ([dateValue floatValue] < minValue) {
                    minValue = [dateValue floatValue];
                }
            }
        }
    }
    if (bSource.count > 0) {
        for (NSDictionary *dict in bSource) {
            NSNumber *dateValue = dict[k_Today_ToalMoney_Key];
            if ([dateValue floatValue] > maxValue) {
                maxValue = [dateValue floatValue];
            }
            if (minValue == 0.00) {
                minValue = [dateValue floatValue];
            }else{
                if ([dateValue floatValue] < minValue) {
                    minValue = [dateValue floatValue];
                }
            }
        }
    }
    if (oSource.count > 0) {
        for (NSDictionary *dict in oSource) {
            NSNumber *dateValue = dict[k_Today_ToalMoney_Key];
            if ([dateValue floatValue] > maxValue) {
                maxValue = [dateValue floatValue];
            }
            if (minValue == 0.00) {
                minValue = [dateValue floatValue];
            }else{
                if ([dateValue floatValue] < minValue) {
                    minValue = [dateValue floatValue];
                }
            }
        }
    }
    
    return @[@(maxValue),@(minValue)];
}
@end
