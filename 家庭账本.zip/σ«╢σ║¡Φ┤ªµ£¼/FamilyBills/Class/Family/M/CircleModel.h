//
//  CircleModel.h
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CircleModel : NSObject
@property (nonatomic ,assign) float value;
@property (nonatomic ,strong) UIColor *color;
@property (nonatomic ,copy) NSString *text;
@property (nonatomic ,strong) NSDictionary *data;
@property (strong, nonatomic) NSArray <NSString *>*plots;
@property (strong, nonatomic) NSMutableArray <UIButton *>*plotButtons;
@property (nonatomic, copy) NSString *project;

+ (instancetype)modelWithColor:(UIColor *)color  plots:(NSArray<NSString *> *)plots project:(NSString *)project;

+ (CGSize)sizeWithText:(NSString *)text fontSize:(CGFloat)fontSize;

+ (UIImage *)imageFromColor:(UIColor *)color rect:(CGRect)rect;

+ (CAShapeLayer *)shapeLayerWithPath:(UIBezierPath *)path lineWidth:(CGFloat)lineWidth fillColor:(UIColor *)fillColor strokeColor:(UIColor *)strokeColor;

+ (BOOL)getIsIpad;
+ (NSArray *)getMaxAndMinValue;
@end
