//
//  StatisticsCircleView.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "StatisticsCircleView.h"
#import "CircleModel.h"

@interface StatisticsCircleView()
@property (nonatomic, assign) CGFloat arcWidth;
@property (nonatomic, assign) CGFloat outerArcRadius;
@property (nonatomic, strong) NSArray <NSNumber *>*endPercents;
@property (nonatomic, strong) NSMutableArray <CAShapeLayer *>*layers;
@property (nonatomic, strong) CAShapeLayer *touchLayer;
@property (nonatomic, strong) NSMutableArray <UIView *>*textViews;
@property (strong, nonatomic) UIScrollView *noteView;
@property (nonatomic, strong) NSArray *dataSource;
@end

@implementation StatisticsCircleView
- (NSMutableArray <UIView *>*)textViews
{
    if(!_textViews){
        _textViews = [NSMutableArray array];
    }
    return _textViews;
}
- (NSMutableArray <CAShapeLayer *>*)layers
{
    if(!_layers){
        _layers = [NSMutableArray array];
    }
    return _layers;
}
- (instancetype)initWithCircleFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        _arcWidth = 30;
        _outerArcRadius = (Screen_Width * 0.45 - 30) * 0.5;
    }
    return self;
}
- (void)showCircleViewWithDataSource:(NSArray *)dataSource
{
    float grandfatherAllvalue = [[kNSUserDefaults objectForKey:k_Total_Grandfather_Money] floatValue];
    float grandmotherAllvalue = [[kNSUserDefaults objectForKey:k_Total_Grandmother_Money] floatValue];
    float wifeAllvalue = [[kNSUserDefaults objectForKey:k_Total_Wife_Money] floatValue];
    float selfAllvalue = [[kNSUserDefaults objectForKey:k_Total_Self_Money] floatValue];
    float babyAllvalue = [[kNSUserDefaults objectForKey:k_Total_Baby_Money] floatValue];
    float othersAllvalue = [[kNSUserDefaults objectForKey:k_Total_Others_Money] floatValue];
    
    NSMutableArray *datas = [NSMutableArray array];
    NSArray *dicts = @[@{@"color":UIColorFromRGB(0xfb6e52),
                         @"value":@(grandfatherAllvalue),
                         @"title":@"爷爷"},
                       @{@"color":UIColorFromRGB(0xffc655),
                         @"value":@(grandmotherAllvalue),
                         @"title":@"奶奶"},
                       @{@"color":UIColorFromRGB(0x2cc6ea),
                         @"value":@(wifeAllvalue),
                         @"title":@"妻子"},
                       @{@"color":UIColorFromRGB(0x37d6b7),
                         @"value":@(selfAllvalue),
                         @"title":@"丈夫"},
                       @{@"color":UIColorFromRGB(0xeb9aff),
                         @"value":@(babyAllvalue),
                         @"title":@"孩子"},
                       @{@"color":UIColorFromRGB(0x55AC43),
                         @"value":@(othersAllvalue),
                         @"title":@"其他"}];
    for (int i = 0; i < dicts.count;i++ ) {
        CircleModel *circleModel = [[CircleModel alloc] init];
        circleModel.data = dicts[i];
        [datas addObject:circleModel];
    }
    
    self.dataSource = datas;
    [self showCircleView];
}
- (void)showCircleView
{
    if (!self.dataSource.count) {
        return;
    }
    [self resetData];
    [self handleData];
    CGFloat radius = self.outerArcRadius - self.arcWidth / 2;
    for (int i = 0; i < self.dataSource.count; i ++) {
        CircleModel *model = self.dataSource[i];
        CGFloat startP = i == 0 ? 0 : self.endPercents[i - 1].doubleValue;
        CGFloat endP = self.endPercents[i].doubleValue;
        
        CAShapeLayer *layer = [self layerWithRadius:radius borderWidth:self.arcWidth fillColor:[UIColor clearColor] strokeColor:model.color startPercentage:startP endPercentage:endP];
        
        [self.layer addSublayer:layer];
        [self.layers addObject:layer];
    }
    [self addText];
}
- (void)resetData {
    if (self.layers.count) {
        [self.layers makeObjectsPerformSelector:@selector(removeFromSuperlayer)];
        [self.layers removeAllObjects];
    }
    
    if (self.textViews.count) {
        [self.textViews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        [self.textViews removeAllObjects];
    }
}
- (void)handleData{
    
    CGFloat dayAllvalue = [[kNSUserDefaults objectForKey:k_Total_Family_Money] floatValue];
    if (dayAllvalue == 0) {
        self.endPercents = @[@(0),@(0),@(0),@(0),@(0),@(1)];
        return;
    }
    NSMutableArray <NSNumber *>*endPercents = [[NSMutableArray alloc] init];
    for (int i = 0;  i < self.dataSource.count; i++) {
        CircleModel *model = self.dataSource[i];
        if (i == 0) {
            [endPercents addObject:@(model.value / dayAllvalue)];
        } else {
            [endPercents addObject:@(model.value / dayAllvalue + endPercents.lastObject.doubleValue)];
        }
    }
    self.endPercents = endPercents.copy;
}
- (CAShapeLayer *)layerWithRadius:(CGFloat)radius borderWidth:(CGFloat)borderWidth fillColor:(UIColor *)fillColor strokeColor:(UIColor *)strokeColor startPercentage:(CGFloat)startP endPercentage:(CGFloat)endP{
    CAShapeLayer *layer = [CAShapeLayer layer];
    CGPoint center = CGPointMake(self.width * 0.25, self.height / 2);
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:-M_PI_2 endAngle:M_PI_2 * 3 clockwise:YES];
    layer.fillColor   = fillColor.CGColor;
    layer.strokeColor = strokeColor.CGColor;
    layer.strokeStart = startP;
    layer.strokeEnd   = endP;
    layer.lineWidth   = borderWidth;
    layer.path        = path.CGPath;
    
    return layer;
}
- (void)addText {
    
    CGFloat H = (self.height - 40) / self.dataSource.count;
    
    for (int i = 0; i < self.dataSource.count; i++) {
        CircleModel *model = self.dataSource[i];
        UIView *textView = [self creatCircleTextView:CGRectMake(self.width * 0.5,20 + i * H, self.width * 0.5, H) WithColor:model.color WithTitle:model.text WithValue:model.value];
        [self addSubview:textView];
        [self.textViews addObject:textView];
    }
}
- (UIView *)creatCircleTextView:(CGRect )frame WithColor:(UIColor *)color WithTitle:(NSString *)title WithValue:(float)value
{
    UIView *textView = [[UIView alloc] initWithFrame:frame];
    UIView *colorView = [[UIView alloc] init];
    colorView.backgroundColor = color;
    colorView.layer.cornerRadius = 5;
    colorView.clipsToBounds = YES;
    if ([CircleModel getIsIpad]) {
        colorView.center = CGPointMake(5, textView.height * 0.5);
    }else{
        colorView.center = CGPointMake(10, textView.height * 0.5);
    }
    colorView.bounds = CGRectMake(0, 0, 10, 10);
    [textView addSubview:colorView];
    
    UILabel *titleLab = [[UILabel alloc] init];
    if ([CircleModel getIsIpad]){
        titleLab.frame = CGRectMake(10 + LineX(5), 0, 80, textView.height);
    }else{
        titleLab.frame = CGRectMake(15 + LineX(10), 0, 80, textView.height);
    }
    titleLab.text = title;
//    titleLab.backgroundColor = [UIColor redColor];
    titleLab.textColor = UIColorFromRGB(0x666666);
    titleLab.font = Font(10.0f);
    [textView addSubview:titleLab];
    
    CGFloat dayAllvalue = [[kNSUserDefaults objectForKey:k_Total_Family_Money] floatValue];
    value = value / dayAllvalue * 100;
    NSString *valueStr;
    if (value == 100){
        valueStr = @"100%";
    }else if (value > 0){
        valueStr = [NSString stringWithFormat:@"%.2f%@",value,@"%"];
    }else{
        valueStr = @"0.00%";
    }
    
    UILabel *valueLab = [[UILabel alloc] init];
    if ([CircleModel getIsIpad]){
        valueLab.frame = CGRectMake(80 +10 + LineX(5), 0, self.width * 0.5 - 90 -LineX(5), textView.height);
        valueLab.font = Font(14.0f);

    }else{
        valueLab.frame = CGRectMake(80 +15 + LineX(10), 0, self.width * 0.5 - 95 -LineX(10), textView.height);
        valueLab.font = Font(14.0f);

    }
    valueLab.text = valueStr;
    valueLab.textColor = color;
        [textView addSubview:valueLab];
    return textView;
}
-(UILabel*)labelWithFrame:(CGRect)frame WithText:(NSString*)text WithRange:(NSInteger)number
{
    UILabel*label = [[UILabel alloc] init];
    label.frame = frame;
    NSMutableAttributedString*attributedStr = [[NSMutableAttributedString alloc] initWithString:text];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    //    [paragraphStyle setLineSpacing:3];
    //    [attributedStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [text length])];
    [attributedStr addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSForegroundColorAttributeName:UIColorFromRGB(0x3d3d3d)} range:NSMakeRange(0, number)];
    [attributedStr addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSForegroundColorAttributeName:UIColorFromRGB(0xff6000)} range:NSMakeRange(number, attributedStr.length-number)];
    //    [attributedStr addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSForegroundColorAttributeName:UIColorFromRGB(0x3d3d3d)} range:NSMakeRange(attributedStr.length-1, 1)];
    
    label.attributedText=attributedStr;
    //    label.textAlignment=NSTextAlignmentCenter;
    return label;
}
@end
