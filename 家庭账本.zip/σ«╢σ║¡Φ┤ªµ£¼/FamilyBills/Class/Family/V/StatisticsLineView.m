//
//  StatisticsLineView.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/22.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "StatisticsLineView.h"
#import "CircleModel.h"

static CGFloat yAxisMaxY = 0;
static CGFloat yTextCenterMargin = 0;
/** 显示数据的区域高度 */
static CGFloat dataChartHeight = 0;
static CGFloat axisLabelHieght = 0;
static CGFloat xAxisMaxX = 0;
static CGFloat noteViewRowH = 15;

@interface StatisticsLineView ()<UIScrollViewDelegate, CAAnimationDelegate>
// UI
@property (strong, nonatomic) NSMutableArray <UILabel *>*yAxisLabels;
@property (strong, nonatomic) NSMutableArray <UILabel *>*xAxisLabels;
@property (strong, nonatomic) NSMutableArray <UIView *>*allSubView;
@property (strong, nonatomic) UIScrollView *noteView;
@property (strong, nonatomic) UIScrollView *scrollView;
@property (strong, nonatomic) UILabel *yAxisLabel;
@property (strong, nonatomic) UILabel *xAxisLabel;

// 数据
@property (assign, nonatomic) CGFloat yAxisMaxValue;
@property (strong, nonatomic) NSArray *dataSource;

/** 捏合时记录原先X轴点距离 */
@property (assign, nonatomic) CGFloat orginXAxisMargin;

/** X轴箭头离XAxisLabel距离 */
@property (assign, nonatomic) CGFloat xArrowsToText;
@property (assign, nonatomic) CGPoint originPoint;
/** 第一次动画 */
@property (strong, nonatomic) NSMutableArray <CAShapeLayer *>*firstLayers;
/** 第二次动画 */
@property (strong, nonatomic) NSMutableArray <CAShapeLayer *>*scondLayers;


@end

@implementation StatisticsLineView

#pragma mark - API

- (instancetype)initWithFrame:(CGRect)frame chartViewType:(LCChartViewType)type {
    if (self = [super initWithFrame:frame]) {
        [self initData];
        self.chartViewType = type;
    }
    return self;
}

- (void)showChartViewWithYAxisMaxValue:(CGFloat)yAxisMaxValue dataSource:(NSArray *)dataSource {
    _yAxisMaxValue = yAxisMaxValue;
    self.dataSource = dataSource;
    [self showChartView];
}

#pragma mark - private method
- (void)initData {
    _axisColor = [UIColor darkGrayColor];
    _backColor = [UIColor whiteColor];
    _axisTitleSizeFont = 10;
    _yTextColor = _xTextColor = _plotsButtonColor = _lineChartFillViewColor = [UIColor darkGrayColor];
    _barWidth = 20;
    _yAxisMaxValue = 1000;
    _chartViewType = LCChartViewTypeLine;
    _axisFontSize = 12;
    _plotsLabelFontSize = 9;
    _barMargin = 35;
    _yAxisToLeft = _chartViewRightMargin = _topMargin = 55;
    _displayPlotToLabel = 3;
    _axisWidth = _lineChartWidth = 1;
    _xAxisTextMargin = _orginXAxisMargin = _xArrowsToText = 30;
    _yTextToAxis = _yAxisCount = _plotsButtonWH = 5;
    _yAxisTitle = @"y";
    _xAxisTitle = @"x";
    _lineChartFillView = _showPlotsLabel = NO;
    _showGridding = YES;
    
}

- (void)showChartView {
    if (self.dataSource.count == 0) {
        NSLog(@"请设置展示的点数据");
        return;
    };
    if (self.chartViewType == LCChartViewTypeBar && _xAxisTextMargin < _barWidth + self.barMargin) {
        _xAxisTextMargin = self.orginXAxisMargin = _barWidth + self.barMargin;
    }
    
    [self resetDataSource];
    [self drawYAxis];
    [self drawXAxis];
//    [self drawTilte];
    [self drawYSeparators];
    [self drawBarChartViewBars];//改
    [self drawDisplayLabels];
}

#pragma mark - 重置数据
- (void)resetDataSource {
    
    // 移除所有的Label,CAShapeLayer
    if (self.allSubView) {
        [self.allSubView makeObjectsPerformSelector:@selector(removeFromSuperview)];
        [self.allSubView removeAllObjects];
    }
    if (self.firstLayers.count) {
        [self.firstLayers makeObjectsPerformSelector:@selector(removeFromSuperlayer)];
        [self.firstLayers removeAllObjects];
    }
    if (self.scondLayers.count) {
        [self.scondLayers makeObjectsPerformSelector:@selector(removeFromSuperlayer)];
        [self.scondLayers removeAllObjects];
    }
    if (self.xAxisLabels.count) {
        [self.xAxisLabels makeObjectsPerformSelector:@selector(removeFromSuperview)];
        [self.xAxisLabels removeAllObjects];
    }
    if (self.yAxisLabels.count) {
        [self.yAxisLabels makeObjectsPerformSelector:@selector(removeFromSuperview)];
        [self.yAxisLabels removeAllObjects];
    }
}

#pragma mark - 描绘Y轴
- (void)drawYAxis {
    axisLabelHieght = [CircleModel sizeWithText:@"x" fontSize:_axisFontSize].height;
    // 数据展示的高度
    dataChartHeight = self.height - _topMargin - _xTextToAxis - axisLabelHieght;
    
    // ylabel之间的间隙
    yTextCenterMargin = dataChartHeight / _yAxisCount;
    yAxisMaxY = MAX(_topMargin - yTextCenterMargin / 2, 0);
    UIBezierPath *yAxisPath = [UIBezierPath bezierPath];
    _originPoint = CGPointMake(_yAxisToLeft, self.height - axisLabelHieght - _xTextToAxis);
    [yAxisPath moveToPoint:_originPoint];
    [yAxisPath addLineToPoint:CGPointMake(_yAxisToLeft, yAxisMaxY)];
    [yAxisPath addLineToPoint:CGPointMake(_yAxisToLeft - (_axisWidth + 2), yAxisMaxY + (_axisWidth + 2))];
    [yAxisPath moveToPoint:CGPointMake(_yAxisToLeft, yAxisMaxY)];
    [yAxisPath addLineToPoint:CGPointMake(_yAxisToLeft + (_axisWidth + 2), yAxisMaxY + (_axisWidth + 2))];
    
    CAShapeLayer *shapeLayer = [self shapeLayerWithPath:yAxisPath lineWidth:_axisWidth fillColor:[UIColor clearColor] strokeColor:_axisColor];
    [self.layer addSublayer:shapeLayer];
    [self.firstLayers addObject:shapeLayer];
    
    // 添加Y轴Label
    for (int i = 0; i < _yAxisCount + 1; i++) {
        CGFloat avgValue = _yAxisMaxValue / (_yAxisCount);
        NSString *title = [NSString stringWithFormat:@"$%.0f", avgValue * i];
        UILabel *label = [self labelWithTextColor:_yTextColor backColor:[UIColor clearColor] textAlignment:NSTextAlignmentRight lineNumber:1 tiltle:title fontSize:_axisFontSize];
        if (_yAxisLabelUIBlock) {
            _yAxisLabelUIBlock(label, i);
        }
        label.x = 0;
        label.height = axisLabelHieght;
        label.width = _yAxisToLeft - _yTextToAxis;
        label.centerY = _topMargin + (_yAxisCount - i) * yTextCenterMargin;
        [self addSubview:label];
        [self.yAxisLabels addObject:label];
    }
    [self.allSubView addObjectsFromArray:self.yAxisLabels];
    
    // yTitleLabel
    _yAxisLabel = [self labelWithTextColor:_axisColor backColor:[UIColor clearColor] textAlignment:NSTextAlignmentLeft lineNumber:1 tiltle:self.yAxisTitle fontSize:_axisTitleSizeFont];
    if (_yAxisTitleLabelUIBlock) {
        _yAxisTitleLabelUIBlock(_yAxisLabel);
    }
    [_yAxisLabel sizeToFit];
    _yAxisLabel.y = yAxisMaxY - _yAxisLabel.height - 5;
    _yAxisLabel.centerX = _originPoint.x;
    [self addSubview:_yAxisLabel];
    [self.allSubView addObject:_yAxisLabel];
    
    // 添加scrollview
    [self insertSubview:self.scrollView atIndex:0];
    self.scrollView.frame = CGRectMake(_yAxisToLeft, 0, self.width - _yAxisToLeft, self.height);
    
    self.scrollView.backgroundColor = self.backgroundColor = _backColor;
}
#pragma mark - ChartViewBar柱状图
/** 根据显示点描绘柱状图 */
- (void)drawBarChartViewBars {
    
    for (int i = 0; i < self.dataSource.count; i++) {
        NSDictionary *dict = self.dataSource[i];
        UIBezierPath *barPath = [UIBezierPath bezierPath];
        CGFloat startPointX = 0;
        startPointX = self.xAxisLabels[i].centerX;
        [barPath moveToPoint:CGPointMake(startPointX, _originPoint.y)];
        [barPath addLineToPoint:CGPointMake(startPointX, [self getValueHeightWith:[NSString stringWithFormat:@"%@",dict[k_Today_ToalMoney_Key]]])];
        CAShapeLayer *barShapeLayer = [self shapeLayerWithPath:barPath lineWidth:_barWidth fillColor:UIColorFromRGB(0xf0788f) strokeColor:UIColorFromRGB(0xf0788f)];
        [self.scondLayers addObject:barShapeLayer];
        [self.scrollView.layer addSublayer:barShapeLayer];
    }
}
#pragma mark - 描绘X轴
- (void)drawXAxis {
    
   // 添加X轴Label
    
    for (int i = 0; i < self.dataSource.count; i++) {
        NSDictionary *dict = self.dataSource[i];
        NSString *title = dict[k_Today_Date_Key];
        
        UILabel *label = [self labelWithTextColor:_xTextColor backColor:[UIColor clearColor] textAlignment:NSTextAlignmentCenter lineNumber:1 tiltle:title fontSize:_axisFontSize];
        if (_xAxisLabelUIBlock) {
            _xAxisLabelUIBlock(label, i);
        }
        CGSize labelSize = [CircleModel sizeWithText:title fontSize:_axisFontSize];
        label.x = (i + 1) * _xAxisTextMargin - labelSize.width / 2;
        label.y = self.height - labelSize.height;
        label.size = labelSize;
        [self.scrollView addSubview:label];
        [self.xAxisLabels addObject:label];
    }
    [self.allSubView addObjectsFromArray:self.xAxisLabels];
    // 处理重叠label
    [self handleOverlapViewWithViews:self.xAxisLabels];
    // 画轴
    UIBezierPath *xAxisPath = [UIBezierPath bezierPath];
    [xAxisPath moveToPoint:CGPointMake(0, _originPoint.y)];
    xAxisMaxX = (self.dataSource.count + 1) * _xAxisTextMargin;
    
    if (xAxisMaxX < (self.width - _yAxisToLeft - 10)) {
        xAxisMaxX = self.width - _yAxisToLeft - 10;
    }
    // scrollView的contentSize
    self.scrollView.contentSize = CGSizeMake(xAxisMaxX + self.chartViewRightMargin, 0);
    
    [xAxisPath addLineToPoint:CGPointMake(xAxisMaxX, _originPoint.y)];
    [xAxisPath addLineToPoint:CGPointMake(xAxisMaxX - (_axisWidth + 2), _originPoint.y - (_axisWidth + 2))];
    [xAxisPath moveToPoint:CGPointMake(xAxisMaxX, _originPoint.y)];
    [xAxisPath addLineToPoint:CGPointMake(xAxisMaxX - (_axisWidth + 2) , _originPoint.y + (_axisWidth + 2))];
    CAShapeLayer *xAxisLayer = [self shapeLayerWithPath:xAxisPath lineWidth:_axisWidth fillColor:[UIColor clearColor] strokeColor:_axisColor];
    [self.scrollView.layer addSublayer:xAxisLayer];
    [self.firstLayers addObject:xAxisLayer];
    
    // xTitleLabel
    _xAxisLabel = [self labelWithTextColor:_axisColor backColor:[UIColor clearColor] textAlignment:NSTextAlignmentCenter lineNumber:1 tiltle:self.xAxisTitle fontSize:_axisTitleSizeFont];
    if (_xAxisTitleLabelUIBlock) {
        _xAxisTitleLabelUIBlock(_xAxisLabel);
    }
    [_xAxisLabel sizeToFit];
    _xAxisLabel.x = xAxisMaxX + 5;
    _xAxisLabel.centerY = _originPoint.y;
    [self.scrollView addSubview:_xAxisLabel];
    [self.allSubView addObject:_xAxisLabel];
}

#pragma mark - 标题
- (void)drawTilte {
    // titleLabel
    UILabel *titleLabel = [self labelWithTextColor:_axisColor backColor:[UIColor clearColor] textAlignment:NSTextAlignmentCenter lineNumber:1 tiltle:@"sadaf" fontSize:_titleFontSize];
    if (_comfigurateTitleLabel) {
        _comfigurateTitleLabel(titleLabel);
    }
    [titleLabel sizeToFit];
    titleLabel.centerX = self.width / 2;
    titleLabel.y = 5;
    [self addSubview:titleLabel];
    [self.allSubView addObject:titleLabel];
}

#pragma mark - Y轴分割线
- (void)drawYSeparators {
    // 添加Y轴分割线
    for (int i = 0; i < self.yAxisLabels.count; i++) {
        CAShapeLayer *yshapeLayer = nil;
        UIBezierPath *ySeparatorPath = [UIBezierPath bezierPath];
        if (_showGridding) {
            [ySeparatorPath moveToPoint:CGPointMake(0, self.yAxisLabels[i].centerY)];
            [ySeparatorPath addLineToPoint:CGPointMake(xAxisMaxX, self.yAxisLabels[i].centerY)];
            yshapeLayer = [self shapeLayerWithPath:ySeparatorPath lineWidth:0.5 fillColor:[UIColor clearColor] strokeColor:_axisColor];
            yshapeLayer.lineDashPattern = @[@(3), @(3)];
            [self.scrollView.layer addSublayer:yshapeLayer];
        } else {
            [ySeparatorPath moveToPoint:CGPointMake(_yAxisToLeft, self.yAxisLabels[i].centerY)];
            [ySeparatorPath addLineToPoint:CGPointMake(_yAxisToLeft + 5, self.yAxisLabels[i].centerY)];
            yshapeLayer = [self shapeLayerWithPath:ySeparatorPath lineWidth:_axisWidth fillColor:[UIColor clearColor] strokeColor:_axisColor];
            [self.layer addSublayer:yshapeLayer];
        }
        [self.firstLayers addObject:yshapeLayer];
    }
}

#pragma mark - 显示数据label
- (void)drawDisplayLabels {
    if (!_showPlotsLabel) {
        return;
    }
    for (int i = 0 ; i < self.dataSource.count; i++) {
        NSDictionary *dict = self.dataSource[i];
        NSMutableArray *plotLabels = [NSMutableArray array];
        NSString *value = dict[@"value"];
        if (value.floatValue < 0) {
            value = @"0";
        }
        UILabel *label = [self labelWithTextColor:self.plotsLabelColor backColor:[UIColor clearColor] textAlignment:NSTextAlignmentCenter lineNumber:1 tiltle:value fontSize:self.plotsLabelFontSize];
        label.tag = i;
        [label sizeToFit];
        
        label.centerX = self.xAxisLabels[i].centerX + i  * _barWidth;
        
        label.bottom = [self getValueHeightWith:value] - _displayPlotToLabel;
        [self.scrollView addSubview:label];
        [plotLabels addObject:label];
        [self.allSubView addObjectsFromArray:plotLabels];
        // 处理重叠label
        [self handleOverlapViewWithViews:plotLabels];
    }
}




#pragma mark - private method
/** 处理label重叠显示的情况 */
- (void)handleOverlapViewWithViews:(NSArray <UIView *>*)views {
    // 如果Label的文字有重叠，那么隐藏
    UIView *firstView = views.firstObject;
    for (int i = 1; i < views.count; i++) {
        UIView *view = views[i];
        CGFloat maxX = CGRectGetMaxX(firstView.frame);
        if ((maxX + 3) > view.x) {
            view.hidden = YES;
        }else{
            view.hidden = NO;
            firstView = view;
        }
    }
}

- (CAShapeLayer *)shapeLayerWithPath:(UIBezierPath *)path lineWidth:(CGFloat)lineWidth fillColor:(UIColor *)fillColor strokeColor:(UIColor *)strokeColor {
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.lineWidth = lineWidth;
    shapeLayer.fillColor = fillColor.CGColor;
    shapeLayer.strokeColor = strokeColor.CGColor;
    shapeLayer.lineCap = kCALineCapButt;
    shapeLayer.lineJoin = kCALineJoinBevel;
    shapeLayer.path = path.CGPath;
    return shapeLayer;
}

/** 数据点高度 */
- (CGFloat)getValueHeightWith:(NSString *)value {
    return dataChartHeight - value.floatValue / _yAxisMaxValue * dataChartHeight + _topMargin;
}

/** label */
- (UILabel *)labelWithTextColor:(UIColor *)textColor backColor:(UIColor *)backColor textAlignment:(NSTextAlignment)textAlignment lineNumber:(NSInteger)number tiltle:(NSString *)title fontSize:(CGFloat)fontSize {
    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    label.textColor = textColor;
    if (backColor) {
        label.backgroundColor = backColor;
    }
    label.textAlignment = textAlignment;
    label.numberOfLines = number;
    if (fontSize != 0) {
        label.font = [UIFont systemFontOfSize:fontSize];
    }
    
    return label;
}

/** 根据颜色生成图片 */
+ (UIImage *)imageFromColor:(UIColor *)color rect:(CGRect)rect{
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}


#pragma mark - response

- (void)plotsButtonDidClick:(UIButton *)button {
    if (self.plotClickBlock) {
        self.plotClickBlock(button.tag);
    }
}

#pragma mark - setter

- (void)setXAxisTextMargin:(CGFloat)xAxisTextMargin {
    _xAxisTextMargin = xAxisTextMargin;
    _xArrowsToText = xAxisTextMargin;
}

- (void)setChartViewXAxisTextMargin:(CGFloat)xAxisTextMargin {
    _xAxisTextMargin = xAxisTextMargin;
    _orginXAxisMargin = xAxisTextMargin;
}

#pragma mark - getter

- (NSMutableArray<UILabel *> *)yAxisLabels {
    if (!_yAxisLabels) {
        _yAxisLabels = [[NSMutableArray alloc] init];
    }
    return _yAxisLabels;
}

- (NSMutableArray<UILabel *> *)xAxisLabels {
    if (!_xAxisLabels) {
        _xAxisLabels = [[NSMutableArray alloc] init];
    }
    return _xAxisLabels;
}

- (NSMutableArray<CAShapeLayer *> *)firstLayers {
    if (!_firstLayers) {
        _firstLayers = [[NSMutableArray alloc] init];
    }
    return _firstLayers;
}

- (NSMutableArray<CAShapeLayer *> *)scondLayers {
    if (!_scondLayers) {
        _scondLayers = [[NSMutableArray alloc] init];
    }
    return _scondLayers;
}

- (NSMutableArray<UIView *> *)allSubView {
    if (!_allSubView) {
        _allSubView = [[NSMutableArray alloc] init];
    }
    return _allSubView;
}

- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.delegate = self;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.bounces = NO;
    }
    return _scrollView;
}

- (UIScrollView *)noteView {
    if (!_noteView) {
        _noteView = [[UIScrollView alloc] init];
        _noteView.showsVerticalScrollIndicator = NO;
        _noteView.width = 80;
        _noteView.height = _topMargin - 2 * 10;
        _noteView.right = self.width - 10;
        _noteView.y = 10;
    }
    return _noteView;
}

- (CGFloat)xArrowsToText {
    if (_xArrowsToText < 8) {
        return 8;
    }
    return _xArrowsToText;
}

@end
