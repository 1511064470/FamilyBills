//
//  ListTableViewCell.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "ListTableViewCell.h"

@implementation ListTableViewCell

- (void)setData:(NSDictionary *)data
{
    _data = data;
    _dateLabel.text = data[k_Date_Key];
    _contentLab.text = data[k_Title_Key];
    _moneyLab.text = [NSString stringWithFormat:@"$%@",data[k_Money_Key]];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
