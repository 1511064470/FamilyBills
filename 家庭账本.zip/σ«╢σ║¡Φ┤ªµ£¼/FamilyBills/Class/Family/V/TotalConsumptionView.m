//
//  TotalConsumptionView.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "TotalConsumptionView.h"

@implementation TotalConsumptionView

- (instancetype)initWithTotalConsumptionViewFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self createBaseView];
    }
    return self;
}
- (void)createBaseView
{
    self.layer.cornerRadius = 5;
    self.backgroundColor = [UIColor whiteColor];
    
    self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, LineX(12), self.width, 20)];
    _titleLab.textColor = UIColorFromRGB(0x999999);
    _titleLab.font = Font(15.0);
    _titleLab.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_titleLab];
    
    self.moneyLab = [[UILabel alloc] initWithFrame:CGRectMake(0, LineX(20) + 20, self.width, 30)];
    _moneyLab.textColor = Main_Color;
    _moneyLab.font = Font(30.0);
    _moneyLab.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_moneyLab];
}
- (void)updateTotalValue:(NSString *)title WithValue:(NSNumber *)value
{
    self.titleLab.text = title;
    self.moneyLab.text = [NSString stringWithFormat:@"¥%0.2f",[value floatValue]];
}
@end
