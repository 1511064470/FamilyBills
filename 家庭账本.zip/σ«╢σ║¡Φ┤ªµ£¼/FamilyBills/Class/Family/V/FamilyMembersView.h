//
//  FamilyMembersView.h
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FamilyMembersView : UIView
@property (nonatomic ,copy) void(^familyMembersSelectBlock)(NSInteger);

- (instancetype)initWithFamilyMembersViewFrame:(CGRect)frame;
- (void)updateMembers;
@end
