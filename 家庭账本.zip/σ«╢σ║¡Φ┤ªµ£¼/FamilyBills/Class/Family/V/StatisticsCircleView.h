//
//  StatisticsCircleView.h
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatisticsCircleView : UIView

- (instancetype)initWithCircleFrame:(CGRect)frame;
- (void)showCircleViewWithDataSource:(NSArray *)dataSource;
@end
