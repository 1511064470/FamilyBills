//
//  TotalConsumptionView.h
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TotalConsumptionView : UIView

@property (nonatomic ,strong) UILabel *titleLab;
@property (nonatomic ,strong) UILabel *moneyLab;
- (instancetype)initWithTotalConsumptionViewFrame:(CGRect)frame;
- (void)updateTotalValue:(NSString *)title WithValue:(NSNumber *)value;
@end
