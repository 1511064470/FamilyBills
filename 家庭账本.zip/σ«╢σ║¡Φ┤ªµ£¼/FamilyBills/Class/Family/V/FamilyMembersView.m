//
//  FamilyMembersView.m
//  FamilyBills
//
//  Created by jianghua on 2018/7/21.
//  Copyright © 2018年 hjh. All rights reserved.
//

#import "FamilyMembersView.h"

@interface FamilyMembersView()
@property (nonatomic ,strong) UIScrollView *baseScrollView;
@property (nonatomic ,strong) UIButton *selectBtn;
@end

@implementation FamilyMembersView
- (UIScrollView *)baseScrollView
{
    if (!_baseScrollView) {
        _baseScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
        _baseScrollView.bounces = NO;
        _baseScrollView.showsHorizontalScrollIndicator = NO;
        [self addSubview:_baseScrollView];
    }
    return _baseScrollView;
}
- (instancetype)initWithFamilyMembersViewFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        [self updateMembers];
    }
    return self;
}
- (void)updateMembers
{
    NSArray *members = @[@"爷爷",@"奶奶",@"妻子",@"丈夫",@"孩子",@"其他"];
    float currentX = 12;
    for (int i = 0; i < members.count; i++) {
        
        NSString *titleStr = members[i];
        CGSize textSize = [titleStr boundingRectWithSize:CGSizeMake(1000, 1000) options:NSStringDrawingTruncatesLastVisibleLine attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]} context:nil].size;
        float currentW = textSize.width > 50 ? textSize.width : 50;
        UIButton *button = [self createMemberButtonWithFrame:CGRectMake(currentX, 11, currentW + 15, 31) WithTitle:titleStr];
        [button addTarget:self action:@selector(memberButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = 100 + i;
        [self.baseScrollView addSubview:button];
        currentX = currentX + currentW + 9 + 15;
        if (button.tag == 100) {
            button.selected = YES;
            button.backgroundColor = Main_Color;
            self.selectBtn = button;
        }
    }
    self.baseScrollView.contentSize = CGSizeMake(currentX, self.height);
}
- (void)memberButtonClick:(UIButton *)button
{
    if (button != self.selectBtn) {
        self.selectBtn.selected = NO;
        self.selectBtn.backgroundColor = [UIColor whiteColor];
        button.backgroundColor = Main_Color;
        button.selected = YES;
        self.selectBtn = button;
    }
    if (self.familyMembersSelectBlock) {
        self.familyMembersSelectBlock(button.tag - 100);
    }
}
- (UIButton *)createMemberButtonWithFrame:(CGRect)frame WithTitle:(NSString *)title
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [button setTitleColor:Main_Color forState:UIControlStateNormal];
    button.layer.borderWidth = 1;
    button.layer.borderColor = Main_Color.CGColor;
    button.layer.cornerRadius = 5;
    button.clipsToBounds = YES;
    button.titleLabel.font = [UIFont systemFontOfSize:15];
    return button;
}
@end
